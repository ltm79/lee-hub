import type { Answers } from "@/lib/desk/types";

export function num(value: string | undefined): number {
  if (!value) return Number.NaN;
  const n = Number(value.replace(/[$,%\s,]/g, ""));
  return Number.isFinite(n) ? n : Number.NaN;
}

export function money(value: number): string {
  if (!Number.isFinite(value)) return "";
  return value.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function dollars(value: number): string {
  const formatted = money(value);
  return formatted ? `$${formatted}` : "";
}

export type RentRow = {
  active: boolean;
  subtotal: number;
  commission: number;
};

export function leaseMath(answers: Answers): {
  rows: RentRow[];
  consideration: number;
  commission: number;
  any: boolean;
} {
  const rows: RentRow[] = [];
  for (let i = 1; i <= 10; i += 1) {
    const rent = num(answers[`row${i}Rent`]);
    const months = num(answers[`row${i}Months`]);
    const pct = num(answers[`row${i}Pct`]);
    const active = [answers[`row${i}From`], answers[`row${i}To`], answers[`row${i}Rent`], answers[`row${i}Months`], answers[`row${i}Pct`]].some(
      (value) => Boolean(value?.trim()),
    );
    const subtotal = rent * months;
    const commission = (subtotal * pct) / 100;
    rows.push({
      active,
      subtotal: active && Number.isFinite(subtotal) ? subtotal : Number.NaN,
      commission: active && Number.isFinite(subtotal) && Number.isFinite(pct) ? commission : Number.NaN,
    });
  }
  const consideration = rows.reduce((sum, row) => sum + (Number.isFinite(row.subtotal) ? row.subtotal : 0), 0);
  const commission = rows.reduce((sum, row) => sum + (Number.isFinite(row.commission) ? row.commission : 0), 0);
  return { rows, consideration, commission, any: rows.some((row) => row.active) };
}

export function splitNet(gross: string | undefined, pct: string | undefined): string {
  const base = num(gross);
  const rate = num(pct);
  if (!pct?.trim() || !Number.isFinite(base) || !Number.isFinite(rate)) return "";
  return money((base * rate) / 100);
}

export function splitPercentTotal(answers: Answers): number {
  let total = 0;
  let any = false;
  for (let i = 1; i <= 4; i += 1) {
    const rate = num(answers[`split${i}Pct`]);
    if (Number.isFinite(rate) && answers[`split${i}Pct`]?.trim()) {
      total += rate;
      any = true;
    }
  }
  return any ? total : Number.NaN;
}

export function saleCommission(answers: Answers): { line: number; base: number; ready: boolean } {
  const base = num(answers.saleBase || answers.price);
  const pct = num(answers.salePct);
  if (!Number.isFinite(base) || !Number.isFinite(pct)) {
    return { line: Number.NaN, base, ready: false };
  }
  return { line: (base * pct) / 100, base, ready: true };
}

export function pdfText(value: string | undefined): string {
  if (!value) return "";
  return value
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[–—]/g, "-")
    .replace(/[^\x0A\x20-\x7E]/g, "")
    .replace(/[ \t]+/g, " ")
    .trim();
}

export function wrapLines(value: string | undefined, count: number, width = 90): string[] {
  const clean = pdfText(value);
  if (!clean) return Array.from({ length: count }, () => "");
  const lines: string[] = [];
  for (const piece of clean.split(/\n/)) {
    let rest = piece.trim();
    if (!rest) {
      lines.push("");
      continue;
    }
    while (rest.length > width) {
      let cut = rest.lastIndexOf(" ", width);
      if (cut < 12) cut = width;
      lines.push(rest.slice(0, cut).trim());
      rest = rest.slice(cut).trim();
    }
    lines.push(rest);
  }
  return Array.from({ length: count }, (_, index) => lines[index] ?? "");
}
