import { useState } from "react";
import type { Answers, Kind } from "@/lib/desk/types";
import { dollars, leaseMath, saleCommission, splitNet, splitPercentTotal } from "@/lib/desk/money";
import { FilesPanel } from "@/components/desk/files-panel";
import { Card, Checks, Choice, Field, read, SecondaryButton } from "@/components/desk/ui";

type SetAnswer = (key: string, value: string) => void;

export function sectionsFor(kind: Kind): { id: string; label: string }[] {
  if (kind === "lease") {
    return [
      { id: "property", label: "Property" },
      { id: "terms", label: "Terms" },
      { id: "docs", label: "Documents" },
      { id: "agents", label: "Agents" },
      { id: "money", label: "Commission" },
      { id: "invoice", label: "Invoice" },
      { id: "sign", label: "Sign" },
    ];
  }
  if (kind === "sale") {
    return [
      { id: "property", label: "Property" },
      { id: "docs", label: "Documents" },
      { id: "agents", label: "Parties" },
      { id: "money", label: "Commission" },
      { id: "invoice", label: "Invoice" },
      { id: "sign", label: "Sign" },
    ];
  }
  if (kind === "consult") {
    return [
      { id: "property", label: "Engagement" },
      { id: "docs", label: "Documents" },
      { id: "money", label: "Commission" },
      { id: "invoice", label: "Invoice" },
      { id: "sign", label: "Sign" },
    ];
  }
  return [
    { id: "property", label: "Property" },
    { id: "money", label: "Commission" },
    { id: "files", label: "Files" },
    { id: "sign", label: "Sign" },
  ];
}

const PROPERTY_TYPES = [
  { value: "industrial", label: "Industrial" },
  { value: "land", label: "Land" },
  { value: "office", label: "Office" },
  { value: "retail", label: "Retail" },
];

function slotCount(answers: Answers, prefix: string, total: number, minimum: number) {
  let count = minimum;
  for (let i = 1; i <= total; i += 1) {
    const hit = Object.keys(answers).some((key) => key.startsWith(`${prefix}${i}`) && answers[key]);
    if (hit) count = Math.max(count, i);
  }
  return count;
}

function PropertyBlock({
  answers,
  set,
  showType,
}: {
  answers: Answers;
  set: SetAnswer;
  showType: boolean;
}) {
  return (
    <div className="grid gap-4">
      {showType ? (
        <Choice
          label="Property type"
          value={read(answers, "propertyType")}
          onChange={(value) => set("propertyType", value)}
          options={PROPERTY_TYPES}
        />
      ) : null}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          className="sm:col-span-2"
          name="address"
          label="Property address"
          value={read(answers, "address")}
          onChange={(value) => set("address", value)}
          placeholder="1400 E Walnut Ave"
        />
        <Field
          name="city"
          label="City, state, ZIP"
          value={read(answers, "city")}
          onChange={(value) => set("city", value)}
          placeholder="Commerce, CA 90040"
        />
        {showType ? (
          <Field
            name="propertyOther"
            label="Other type"
            value={read(answers, "propertyOther")}
            onChange={(value) => set("propertyOther", value)}
            placeholder="Flex, IOS, medical…"
          />
        ) : null}
        {showType ? (
          <Field
            name="sf"
            label="Square feet"
            value={read(answers, "sf")}
            onChange={(value) => set("sf", value)}
            inputMode="decimal"
          />
        ) : null}
      </div>
    </div>
  );
}

function FundsBlock({ answers, set }: { answers: Answers; set: SetAnswer }) {
  return (
    <div className="grid gap-4">
      <Choice
        label="Type of funds"
        value={read(answers, "fundsType")}
        onChange={(value) => set("fundsType", value)}
        options={[
          { value: "check", label: "Check" },
          { value: "wire", label: "Wire" },
          { value: "ach", label: "ACH" },
        ]}
      />
      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          className="sm:col-span-2"
          name="fundsFrom"
          label="Funds received from"
          value={read(answers, "fundsFrom")}
          onChange={(value) => set("fundsFrom", value)}
        />
        <Field
          name="amountReceived"
          label="Amount received"
          value={read(answers, "amountReceived")}
          onChange={(value) => set("amountReceived", value)}
          inputMode="decimal"
        />
        <Field
          name="gross"
          label="Gross to Lee"
          value={read(answers, "gross")}
          onChange={(value) => set("gross", value)}
          inputMode="decimal"
          hint="House splits are a percent of this number."
        />
        <Field
          name="balance"
          label="Outstanding balance"
          value={read(answers, "balance")}
          onChange={(value) => set("balance", value)}
          inputMode="decimal"
        />
        <Field
          name="dueDate"
          label="Due date"
          value={read(answers, "dueDate")}
          onChange={(value) => set("dueDate", value)}
          placeholder="MM/DD/YYYY"
        />
      </div>
    </div>
  );
}

function SplitsBlock({ answers, set }: { answers: Answers; set: SetAnswer }) {
  const [opened, setOpened] = useState(() => slotCount(answers, "split", 4, 2));
  const shown = Math.max(opened, slotCount(answers, "split", 4, 1));
  const percent = splitPercentTotal(answers);
  return (
    <div className="grid gap-4">
      {Number.isFinite(percent) ? (
        <p className={`text-sm ${Math.abs(percent - 100) > 0.2 ? "text-red-deep" : "text-ink-soft"}`}>
          Internal splits add up to {percent}% of gross.
        </p>
      ) : null}
      <div className="grid gap-3 lg:grid-cols-2">
        {Array.from({ length: shown }, (_, index) => {
          const n = index + 1;
          const net = splitNet(answers.gross, answers[`split${n}Pct`]);
          return (
            <div key={n} className="rounded-md border border-line bg-paper p-3">
              <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-muted">Agent {n}</p>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field
                  name={`split${n}Agent`}
                  label="Agent"
                  value={read(answers, `split${n}Agent`)}
                  onChange={(value) => set(`split${n}Agent`, value)}
                />
                <Field
                  name={`split${n}Entity`}
                  label="Entity"
                  value={read(answers, `split${n}Entity`)}
                  onChange={(value) => set(`split${n}Entity`, value)}
                />
                <Field
                  name={`split${n}Pct`}
                  label="% of gross"
                  value={read(answers, `split${n}Pct`)}
                  onChange={(value) => set(`split${n}Pct`, value)}
                  inputMode="decimal"
                />
                <div>
                  <p className="text-sm text-ink-soft">Net commission</p>
                  <p className="mt-2 text-lg font-medium tabular-nums text-ink">{net ? `$${net}` : "—"}</p>
                </div>
                <Field
                  name={`split${n}Runner`}
                  label="Runner"
                  value={read(answers, `split${n}Runner`)}
                  onChange={(value) => set(`split${n}Runner`, value)}
                />
                <Field
                  name={`split${n}RunnerAmt`}
                  label="Runner check"
                  value={read(answers, `split${n}RunnerAmt`)}
                  onChange={(value) => set(`split${n}RunnerAmt`, value)}
                  inputMode="decimal"
                />
              </div>
              <label className="mt-3 flex min-h-11 items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={answers[`split${n}Defer`] === "1"}
                  onChange={(event) => set(`split${n}Defer`, event.target.checked ? "1" : "")}
                  className="size-4 accent-red"
                />
                Defer this split
              </label>
            </div>
          );
        })}
      </div>
      {shown < 4 ? (
        <SecondaryButton onClick={() => setOpened(shown + 1)}>Add another agent</SecondaryButton>
      ) : null}
    </div>
  );
}

function ExternalBlock({ answers, set }: { answers: Answers; set: SetAnswer }) {
  const [opened, setOpened] = useState(() => slotCount(answers, "ext", 2, 1));
  const shown = Math.max(opened, slotCount(answers, "ext", 2, 1));
  return (
    <div className="grid gap-4">
      {Array.from({ length: shown }, (_, index) => {
        const n = index + 1;
        return (
          <div key={n} className="rounded-md border border-line p-3">
            <Choice
              label={`Outside company ${n}`}
              value={read(answers, `ext${n}License`)}
              onChange={(value) => set(`ext${n}License`, value)}
              options={[
                { value: "licensed", label: "Licensed" },
                { value: "unlicensed", label: "Unlicensed" },
              ]}
            />
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Field name={`ext${n}Company`} label="Company" value={read(answers, `ext${n}Company`)} onChange={(value) => set(`ext${n}Company`, value)} />
              <Field name={`ext${n}Contact`} label="Contact" value={read(answers, `ext${n}Contact`)} onChange={(value) => set(`ext${n}Contact`, value)} />
              <Field className="sm:col-span-2" name={`ext${n}Address`} label="Address" value={read(answers, `ext${n}Address`)} onChange={(value) => set(`ext${n}Address`, value)} />
              <Field name={`ext${n}City`} label="City, state, ZIP" value={read(answers, `ext${n}City`)} onChange={(value) => set(`ext${n}City`, value)} />
              <Field name={`ext${n}Email`} label="Email" value={read(answers, `ext${n}Email`)} onChange={(value) => set(`ext${n}Email`, value)} inputMode="email" />
              <Field name={`ext${n}Area`} label="Area code" value={read(answers, `ext${n}Area`)} onChange={(value) => set(`ext${n}Area`, value)} inputMode="tel" />
              <Field name={`ext${n}Phone`} label="Phone" value={read(answers, `ext${n}Phone`)} onChange={(value) => set(`ext${n}Phone`, value)} inputMode="tel" />
              <Field name={`ext${n}Corp`} label="Corp. DRE #" value={read(answers, `ext${n}Corp`)} onChange={(value) => set(`ext${n}Corp`, value)} />
              <Field name={`ext${n}Sales`} label="Salesperson DRE #" value={read(answers, `ext${n}Sales`)} onChange={(value) => set(`ext${n}Sales`, value)} />
              <Field name={`ext${n}Commission`} label="Commission amount" value={read(answers, `ext${n}Commission`)} onChange={(value) => set(`ext${n}Commission`, value)} inputMode="decimal" />
            </div>
          </div>
        );
      })}
      {shown < 2 ? (
        <SecondaryButton onClick={() => setOpened(2)}>Add second outside company</SecondaryButton>
      ) : null}
    </div>
  );
}

function AgentPairs({
  answers,
  set,
  prefix,
  title,
}: {
  answers: Answers;
  set: SetAnswer;
  prefix: "list" | "proc";
  title: string;
}) {
  const [opened, setOpened] = useState(() => slotCount(answers, prefix, 3, 1));
  const shown = Math.max(opened, slotCount(answers, prefix, 3, 1));
  return (
    <div>
      <h3 className="mb-3 font-serif text-xl">{title}</h3>
      <div className="grid gap-3">
        {Array.from({ length: shown }, (_, index) => {
          const n = index + 1;
          return (
            <div key={n} className="grid gap-3 sm:grid-cols-2">
              <Field name={`${prefix}${n}Name`} label={`Agent ${n}`} value={read(answers, `${prefix}${n}Name`)} onChange={(value) => set(`${prefix}${n}Name`, value)} />
              <Field name={`${prefix}${n}Firm`} label="Firm" value={read(answers, `${prefix}${n}Firm`)} onChange={(value) => set(`${prefix}${n}Firm`, value)} />
            </div>
          );
        })}
      </div>
      {shown < 3 ? (
        <SecondaryButton className="mt-3" onClick={() => setOpened(shown + 1)}>
          Add agent
        </SecondaryButton>
      ) : null}
    </div>
  );
}

function MarketingBlock({ answers, set }: { answers: Answers; set: SetAnswer }) {
  return (
    <div className="grid gap-4">
      <Checks
        answers={answers}
        onChange={set}
        items={[
          { key: "mktGift", label: "Gift basket" },
          { key: "mktPress", label: "Press release" },
          { key: "mktWeb", label: "Add to website / online resume" },
          { key: "mktSign", label: "Remove sign" },
          { key: "mktCard", label: "Postcard" },
          { key: "mktLeepro", label: "Add to LeePro transaction summary" },
        ]}
      />
      <div className="grid gap-4 sm:grid-cols-2">
        <Field name="mktCriteria" label="Postcard criteria" value={read(answers, "mktCriteria")} onChange={(value) => set("mktCriteria", value)} />
        <Field name="mktRef" label="Reference contact" value={read(answers, "mktRef")} onChange={(value) => set("mktRef", value)} />
      </div>
      <Field
        name="highlights"
        label="Highlights"
        multiline
        value={read(answers, "highlights")}
        onChange={(value) => set("highlights", value)}
      />
    </div>
  );
}

function BillBlock({ answers, set }: { answers: Answers; set: SetAnswer }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field name="billName" label="Invoice name" value={read(answers, "billName")} onChange={(value) => set("billName", value)} />
      <Field name="billCompany" label="Invoice company" value={read(answers, "billCompany")} onChange={(value) => set("billCompany", value)} />
      <Field className="sm:col-span-2" name="billCity" label="Invoice city, state, ZIP" value={read(answers, "billCity")} onChange={(value) => set("billCity", value)} />
    </div>
  );
}

function OfficeBlock({ answers, set }: { answers: Answers; set: SetAnswer }) {
  return (
    <details className="rounded-md border border-line bg-paper px-3 py-2">
      <summary className="min-h-11 cursor-pointer text-sm font-medium text-ink-soft">Office use only</summary>
      <div className="grid gap-3 pb-2 sm:grid-cols-2">
        <Field name="officeSl" label="S & L #" value={read(answers, "officeSl")} onChange={(value) => set("officeSl", value)} />
        <Field name="officeEntered" label="Entered" value={read(answers, "officeEntered")} onChange={(value) => set("officeEntered", value)} placeholder="MM/DD/YYYY" />
        <Field name="officePaid" label="Paid" value={read(answers, "officePaid")} onChange={(value) => set("officePaid", value)} placeholder="MM/DD/YYYY" />
        <Field name="officeCommerce" label="Commerce" value={read(answers, "officeCommerce")} onChange={(value) => set("officeCommerce", value)} />
      </div>
    </details>
  );
}

function SignBlock({
  answers,
  set,
  extra,
}: {
  answers: Answers;
  set: SetAnswer;
  extra?: string;
}) {
  return (
    <div className="grid gap-4">
      <p className="text-sm text-ink-soft">
        I certify that the information in this voucher is true and correct to the best of my knowledge.
        {extra ? ` ${extra}` : ""} Typing a name places it on the signature line of the PDF. The broker can still sign the paper copy.
      </p>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field name="agentSign" label="Agent signature" value={read(answers, "agentSign")} onChange={(value) => set("agentSign", value)} />
        <Field name="brokerSign" label="Broker signature" value={read(answers, "brokerSign")} onChange={(value) => set("brokerSign", value)} />
      </div>
      <Field name="comments" label="Comments" multiline value={read(answers, "comments")} onChange={(value) => set("comments", value)} />
      <OfficeBlock answers={answers} set={set} />
    </div>
  );
}

function RentSchedule({ answers, set }: { answers: Answers; set: SetAnswer }) {
  const math = leaseMath(answers);
  let base = 3;
  math.rows.forEach((row, index) => {
    if (row.active) base = Math.max(base, index + 1);
  });
  const [opened, setOpened] = useState(base);
  const shown = Math.max(opened, base);
  return (
    <div className="grid gap-3">
      <p className="text-sm text-ink-soft">
        Each row prints on page 3. Subtotal is rent times months. Commission is that subtotal times the percent.
      </p>
      {Array.from({ length: shown }, (_, index) => {
        const n = index + 1;
        const row = math.rows[index];
        return (
          <div key={n} className="rounded-md border border-line p-3">
            <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-muted">Period {n}</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-6">
              <Field name={`row${n}From`} label="Mos from" value={read(answers, `row${n}From`)} onChange={(value) => set(`row${n}From`, value)} inputMode="decimal" />
              <Field name={`row${n}To`} label="Mos to" value={read(answers, `row${n}To`)} onChange={(value) => set(`row${n}To`, value)} inputMode="decimal" />
              <Field name={`row${n}Rent`} label="$ / month" value={read(answers, `row${n}Rent`)} onChange={(value) => set(`row${n}Rent`, value)} inputMode="decimal" />
              <Field name={`row${n}Months`} label="Months" value={read(answers, `row${n}Months`)} onChange={(value) => set(`row${n}Months`, value)} inputMode="decimal" />
              <Field name={`row${n}Pct`} label="%" value={read(answers, `row${n}Pct`)} onChange={(value) => set(`row${n}Pct`, value)} inputMode="decimal" />
              <div className="col-span-2 sm:col-span-1">
                <p className="text-sm text-ink-soft">Commission</p>
                <p className="mt-2 tabular-nums font-medium">{row && Number.isFinite(row.commission) ? dollars(row.commission) : "—"}</p>
                <p className="text-xs text-muted tabular-nums">
                  {row && Number.isFinite(row.subtotal) ? `${dollars(row.subtotal)} consideration` : " "}
                </p>
              </div>
            </div>
          </div>
        );
      })}
      {shown < 10 ? (
        <SecondaryButton onClick={() => setOpened(shown + 1)}>Add rent period</SecondaryButton>
      ) : null}
      <div className="flex flex-wrap gap-6 border-t border-line pt-3">
        <p>
          <span className="block text-sm text-ink-soft">Total consideration</span>
          <span className="font-serif text-2xl tabular-nums">{math.any ? dollars(math.consideration) : "—"}</span>
        </p>
        <p>
          <span className="block text-sm text-ink-soft">Total commission</span>
          <span className="font-serif text-2xl tabular-nums">{math.any ? dollars(math.commission) : "—"}</span>
        </p>
      </div>
    </div>
  );
}

export function VoucherSection({
  packetId,
  kind,
  section,
  answers,
  set,
}: {
  packetId: string;
  kind: Kind;
  section: string;
  answers: Answers;
  set: SetAnswer;
}) {
  if (section === "property") {
    if (kind === "lease") {
      return (
        <Card eyebrow="Deal voucher" title="Lease property">
          <div className="grid gap-5">
            <Choice
              label="Transaction"
              value={read(answers, "transaction")}
              onChange={(value) => set("transaction", value)}
              options={[
                { value: "lease", label: "Lease" },
                { value: "sublease", label: "Sublease" },
                { value: "renewal", label: "Lease renewal" },
              ]}
            />
            <PropertyBlock answers={answers} set={set} showType />
          </div>
        </Card>
      );
    }
    if (kind === "consult") {
      return (
        <Card eyebrow="Deal voucher" title="Consulting/Referral">
          <div className="grid gap-5">
            <Choice
              label="Engagement"
              value={read(answers, "engagement")}
              onChange={(value) => set("engagement", value)}
              options={[
                { value: "referral", label: "Referral" },
                { value: "consulting", label: "Consulting" },
              ]}
            />
            <PropertyBlock answers={answers} set={set} showType />
          </div>
        </Card>
      );
    }
    if (kind === "additional") {
      return (
        <Card eyebrow="Additional Payment" title="Property and parties">
          <div className="grid gap-5">
            <PropertyBlock answers={answers} set={set} showType={false} />
            <Parties
              answers={answers}
              set={set}
              left="seller"
              right="buyer"
              leftTitle="Seller / lessor"
              rightTitle="Buyer / lessee"
            />
          </div>
        </Card>
      );
    }
    return (
      <Card eyebrow="Deal voucher" title="Sale property">
        <div className="grid gap-5">
          <PropertyBlock answers={answers} set={set} showType />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field name="asking" label="Asking price" value={read(answers, "asking")} onChange={(value) => set("asking", value)} inputMode="decimal" />
            <Field name="price" label="Purchase price" value={read(answers, "price")} onChange={(value) => set("price", value)} inputMode="decimal" />
            <Field
              name="capRate"
              label="Cap rate"
              value={read(answers, "capRate")}
              onChange={(value) => set("capRate", value)}
              inputMode="decimal"
              placeholder="6.50"
              hint="Percent"
            />
            <Field name="closeDate" label="Close of escrow" value={read(answers, "closeDate")} onChange={(value) => set("closeDate", value)} placeholder="MM/DD/YYYY" />
            <Choice
              label="Buyer type"
              value={read(answers, "buyerType")}
              onChange={(value) => set("buyerType", value)}
              options={[
                { value: "user", label: "User" },
                { value: "investor", label: "Investor" },
              ]}
            />
          </div>
          <Field name="saleNotes" label="Sale comments" multiline value={read(answers, "saleNotes")} onChange={(value) => set("saleNotes", value)} />
        </div>
      </Card>
    );
  }

  if (section === "terms" && kind === "lease") {
    return (
      <div className="grid gap-4">
        <Card title="Parties">
          <div className="grid gap-5">
            <Parties answers={answers} set={set} left="lessor" right="lessee" leftTitle="Lessor" rightTitle="Lessee" />
            <Choice
              label="Lee represented"
              value={read(answers, "represented")}
              onChange={(value) => set("represented", value)}
              options={[
                { value: "lessor", label: "Lessor" },
                { value: "lessee", label: "Lessee" },
                { value: "both", label: "Both" },
              ]}
            />
          </div>
        </Card>
        <Card title="Lease economics">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field name="leaseFrom" label="Lease terms from" value={read(answers, "leaseFrom")} onChange={(value) => set("leaseFrom", value)} placeholder="MM/DD/YYYY" />
            <Field name="leaseThrough" label="Through" value={read(answers, "leaseThrough")} onChange={(value) => set("leaseThrough", value)} placeholder="MM/DD/YYYY" />
            <Field name="executionDate" label="Execution date" value={read(answers, "executionDate")} onChange={(value) => set("executionDate", value)} placeholder="MM/DD/YYYY" />
            <Field name="termMos" label="Term (months)" value={read(answers, "termMos")} onChange={(value) => set("termMos", value)} inputMode="decimal" />
            <Field name="leasedSf" label="Leased SF" value={read(answers, "leasedSf")} onChange={(value) => set("leasedSf", value)} inputMode="decimal" />
            <Field name="buildingSf" label="Total building SF" value={read(answers, "buildingSf")} onChange={(value) => set("buildingSf", value)} inputMode="decimal" />
            <Field name="landSf" label="Land SF" value={read(answers, "landSf")} onChange={(value) => set("landSf", value)} inputMode="decimal" />
            <Field name="officeSf" label="Office SF" value={read(answers, "officeSf")} onChange={(value) => set("officeSf", value)} inputMode="decimal" />
            <Field name="askingRate" label="Asking rate" value={read(answers, "askingRate")} onChange={(value) => set("askingRate", value)} />
            <Field name="askingType" label="Asking rate type" value={read(answers, "askingType")} onChange={(value) => set("askingType", value)} placeholder="NNN" />
            <Field name="leaseRate" label="Lease rate" value={read(answers, "leaseRate")} onChange={(value) => set("leaseRate", value)} />
            <Field name="leaseType" label="Lease rate type" value={read(answers, "leaseType")} onChange={(value) => set("leaseType", value)} />
            <Field name="effectiveRate" label="Effective rate" value={read(answers, "effectiveRate")} onChange={(value) => set("effectiveRate", value)} />
            <Field name="effectiveType" label="Effective rate type" value={read(answers, "effectiveType")} onChange={(value) => set("effectiveType", value)} />
            <Field name="considerationNote" label="Total consideration note" value={read(answers, "considerationNote")} onChange={(value) => set("considerationNote", value)} />
            <Field name="ti" label="TI allowance" value={read(answers, "ti")} onChange={(value) => set("ti", value)} />
            <Field name="leaseOption" label="Lease option terms" value={read(answers, "leaseOption")} onChange={(value) => set("leaseOption", value)} />
            <Field name="purchaseOption" label="Purchase option terms" value={read(answers, "purchaseOption")} onChange={(value) => set("purchaseOption", value)} />
            <Field name="exerciseLeft" label="Exercise time frame" value={read(answers, "exerciseLeft")} onChange={(value) => set("exerciseLeft", value)} />
            <Field name="freeRent" label="Free rent" value={read(answers, "freeRent")} onChange={(value) => set("freeRent", value)} />
            <Field className="sm:col-span-2" name="nnn" label="NNN / CAM charges" value={read(answers, "nnn")} onChange={(value) => set("nnn", value)} />
          </div>
        </Card>
        <Card title="Escalations">
          <div className="grid gap-3">
            {Array.from({ length: 5 }, (_, index) => {
              const n = index + 1;
              return (
                <div key={n} className="grid gap-3 sm:grid-cols-3">
                  <Field name={`esc${n}Period`} label={`Period ${n}`} value={read(answers, `esc${n}Period`)} onChange={(value) => set(`esc${n}Period`, value)} />
                  <Field name={`esc${n}Psf`} label="Rate PSF" value={read(answers, `esc${n}Psf`)} onChange={(value) => set(`esc${n}Psf`, value)} />
                  <Field name={`esc${n}Type`} label="Rate type" value={read(answers, `esc${n}Type`)} onChange={(value) => set(`esc${n}Type`, value)} />
                </div>
              );
            })}
            <Field name="escNotes" label="Escalation comments" multiline value={read(answers, "escNotes")} onChange={(value) => set("escNotes", value)} />
          </div>
        </Card>
      </div>
    );
  }

  if (section === "docs" || section === "files") {
    return <FilesPanel packetId={packetId} kind={kind} answers={answers} set={set} />;
  }

  if (section === "agents") {
    if (kind === "sale") {
      return (
        <div className="grid gap-4">
          <Card title="Seller and buyer">
            <Parties answers={answers} set={set} left="seller" right="buyer" leftTitle="Seller" rightTitle="Buyer" />
          </Card>
          <Card title="Brokers">
            <div className="grid gap-6 lg:grid-cols-2">
              <AgentPairs answers={answers} set={set} prefix="list" title="Listing agents" />
              <AgentPairs answers={answers} set={set} prefix="proc" title="Procuring agents" />
            </div>
          </Card>
        </div>
      );
    }
    return (
      <Card title="Listing and procuring">
        <div className="grid gap-6 lg:grid-cols-2">
          <AgentPairs answers={answers} set={set} prefix="list" title="Listing agents" />
          <AgentPairs answers={answers} set={set} prefix="proc" title="Procuring agents" />
        </div>
      </Card>
    );
  }

  if (section === "money") {
    const sale = saleCommission(answers);
    return (
      <div className="grid gap-4">
        <Card title="Funds received">
          <FundsBlock answers={answers} set={set} />
        </Card>
        {kind === "sale" ? (
          <Card title="Commission math">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field
                name="saleBase"
                label="Consideration in the formula"
                value={read(answers, "saleBase")}
                onChange={(value) => set("saleBase", value)}
                placeholder={answers.price || "Purchase price"}
                inputMode="decimal"
              />
              <Field name="salePct" label="Commission %" value={read(answers, "salePct")} onChange={(value) => set("salePct", value)} inputMode="decimal" />
              <div>
                <p className="text-sm text-ink-soft">Commission</p>
                <p className="mt-2 font-serif text-2xl tabular-nums">{sale.ready ? dollars(sale.line) : "—"}</p>
              </div>
            </div>
          </Card>
        ) : null}
        <Card title="Internal distribution">
          <SplitsBlock answers={answers} set={set} />
        </Card>
        <Card title="Outside companies">
          <ExternalBlock answers={answers} set={set} />
        </Card>
        {kind === "consult" ? (
          <Card title="Distribution note">
            <Field name="sideComment" label="Comment on the commission page" value={read(answers, "sideComment")} onChange={(value) => set("sideComment", value)} />
          </Card>
        ) : null}
      </div>
    );
  }

  if (section === "invoice") {
    return (
      <div className="grid gap-4">
        {kind === "lease" ? (
          <Card title="Total consideration" eyebrow="Page 3 of the lease voucher">
            <RentSchedule answers={answers} set={set} />
          </Card>
        ) : null}
        <Card title="Who to invoice">
          <div className="grid gap-4">
            <Choice
              label="Send an invoice?"
              value={read(answers, "invoice")}
              onChange={(value) => set("invoice", value)}
              options={[
                { value: "yes", label: "Yes" },
                { value: "no", label: "No" },
              ]}
            />
            {answers.invoice === "yes" || kind !== "consult" ? <BillBlock answers={answers} set={set} /> : null}
          </div>
        </Card>
        {kind === "lease" || kind === "sale" ? (
          <Card title="Marketing">
            <MarketingBlock answers={answers} set={set} />
          </Card>
        ) : null}
      </div>
    );
  }

  return (
    <Card title="Certify and sign">
      <SignBlock
        answers={answers}
        set={set}
        extra={
          kind === "additional"
            ? undefined
            : "The required backup items marked on the checklist are included in sequential order."
        }
      />
    </Card>
  );
}

function Parties({
  answers,
  set,
  left,
  right,
  leftTitle,
  rightTitle,
}: {
  answers: Answers;
  set: SetAnswer;
  left: string;
  right: string;
  leftTitle: string;
  rightTitle: string;
}) {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Party answers={answers} set={set} prefix={left} title={leftTitle} />
      <Party answers={answers} set={set} prefix={right} title={rightTitle} />
    </div>
  );
}

function Party({
  answers,
  set,
  prefix,
  title,
}: {
  answers: Answers;
  set: SetAnswer;
  prefix: string;
  title: string;
}) {
  const nameKey = prefix;
  const dbaKey = `${prefix}Dba`;
  const contactKey = `${prefix}Contact`;
  return (
    <div className="grid gap-3 rounded-md border border-line p-3">
      <h3 className="font-serif text-xl">{title}</h3>
      <Field name={nameKey} label="Name" value={read(answers, nameKey)} onChange={(value) => set(nameKey, value)} />
      <Field name={dbaKey} label="Company DBA" value={read(answers, dbaKey)} onChange={(value) => set(dbaKey, value)} />
      <Field name={contactKey} label="Contact" value={read(answers, contactKey)} onChange={(value) => set(contactKey, value)} />
    </div>
  );
}
