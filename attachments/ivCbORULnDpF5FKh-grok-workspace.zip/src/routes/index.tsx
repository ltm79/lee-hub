import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/desk/home-page";

export const Route = createFileRoute("/")({
  component: HomePage,
  head: () => ({
    meta: [
      { title: "Deal Desk" },
      {
        name: "description",
        content:
          "Submit Lee & Associates deal vouchers with the backup files accounting needs, then download one packet.",
      },
    ],
  }),
});
