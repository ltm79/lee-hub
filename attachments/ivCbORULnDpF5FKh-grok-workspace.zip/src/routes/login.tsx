import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { authClient } from "@/lib/auth/client";
import { loginEmail, normalizeLogin, prepareDesk, whoAmI } from "@/lib/desk/people";
import { PrimaryButton } from "@/components/desk/ui";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({
    meta: [{ title: "Sign in · Deal Desk" }],
  }),
});

const BEARER_KEY = "grok-auth.bearer-token";

type EmailCall = {
  email: (
    body: { email: string; password: string; callbackURL: string },
    options?: { onSuccess?: (ctx: { response: Response }) => void },
  ) => Promise<{ error: { message?: string } | null }>;
};

function keepToken(ctx: { response: Response }) {
  const token = ctx.response.headers.get("set-auth-token");
  if (!token) return;
  try {
    sessionStorage.setItem(BEARER_KEY, token);
  } catch {
    /* the cookie still signs them in when the browser allows it */
  }
}

function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    void prepareDesk().catch(() => setError("The desk is not ready to sign in yet."));
  }, []);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    const handle = normalizeLogin(username);
    if (!handle || password.length < 8) {
      setError("Use the username or email and password an admin gave you.");
      return;
    }
    setPending(true);
    const emailAuth = authClient as unknown as { signIn: EmailCall };
    const result = await emailAuth.signIn.email(
      { email: loginEmail(handle), password, callbackURL: "/" },
      { onSuccess: keepToken },
    );
    if (result.error) {
      setPending(false);
      setError(result.error.message || "That login or password is wrong.");
      return;
    }
    const me = await whoAmI().catch(() => null);
    if (!me) {
      try {
        sessionStorage.removeItem(BEARER_KEY);
      } catch {
        /* ignore */
      }
      await authClient.signOut();
      setPending(false);
      setError("This login is not on the desk.");
      return;
    }
    window.location.assign("/");
  }

  return (
    <div className="min-h-screen">
      <div className="h-1 bg-red" />
      <main className="mx-auto grid min-h-[80vh] max-w-md place-items-center px-4 py-10">
        <div className="w-full">
          <p className="text-xs font-semibold uppercase tracking-widest text-red">Lee & Associates</p>
          <h1 className="mt-2 font-serif text-4xl">Deal Desk</h1>
          <p className="mt-3 text-sm text-ink-soft">
            Sign in with the username or email an admin assigned. Agents see their own drafts. Staff see submitted vouchers.
          </p>
          <form className="mt-6 grid gap-3" onSubmit={(event) => void onSubmit(event)}>
            <label className="block">
              <span className="text-sm text-ink-soft">Username or email</span>
              <input
                value={username}
                autoCapitalize="none"
                autoComplete="username"
                onChange={(event) => setUsername(event.target.value)}
                className="mt-1 h-11 w-full rounded-md border border-line bg-card px-3 text-sm text-ink focus-visible:border-red focus-visible:outline-none"
              />
            </label>
            <label className="block">
              <span className="text-sm text-ink-soft">Password</span>
              <input
                type="password"
                value={password}
                autoComplete="current-password"
                onChange={(event) => setPassword(event.target.value)}
                className="mt-1 h-11 w-full rounded-md border border-line bg-card px-3 text-sm text-ink focus-visible:border-red focus-visible:outline-none"
              />
            </label>
            {error ? <p className="text-sm text-red-deep">{error}</p> : null}
            <PrimaryButton type="submit" disabled={pending}>
              {pending ? "Signing in…" : "Sign in"}
            </PrimaryButton>
          </form>
        </div>
      </main>
    </div>
  );
}
