import { createFileRoute } from "@tanstack/react-router";
import { EditorPage } from "@/components/desk/editor-page";

export const Route = createFileRoute("/vouchers/$id")({
  component: VoucherRoute,
  head: () => ({
    meta: [{ title: "Voucher · Deal Desk" }],
  }),
});

function VoucherRoute() {
  const { id } = Route.useParams();
  return <EditorPage id={id} />;
}
