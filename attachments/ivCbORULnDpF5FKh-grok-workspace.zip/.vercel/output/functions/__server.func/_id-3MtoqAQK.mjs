import { o as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./_id-Dzcdk-_z.mjs";
import { a as PrimaryButton, i as Field, m as read, n as Checks, o as SecondaryButton, r as Choice, t as Card } from "./_ssr/ui-mSmsEGFd.mjs";
import { C as splitNet, D as useDesk, E as useCurrentUserState, O as useDeskHydrated, S as saveBlob, T as storeIncoming, _ as leaseMath, a as UserButton, b as saleCommission, c as deleteBlob, d as downloadPacket, f as downloadVoucher, g as hydrateSubmitted, h as getBlob, i as RedirectToSignIn, k as useMember, l as docGroups, m as formatBytes, n as KIND_META, o as blockers, p as emailPacket, s as checkedWithoutFile, t as ACCEPT, u as dollars, v as packetFiles, w as splitPercentTotal, y as packetTitle } from "./_ssr/gates-DYOQ7Lhd.mjs";
import { a as Mail, c as FileText, f as ArrowLeft, i as Paperclip, l as Download, s as FolderArchive, t as X } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-3MtoqAQK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function isLoginRequired(result) {
	return result.ok === false && result.loginRequired === true;
}
function isFramed() {
	try {
		return window.self !== window.top;
	} catch {
		return true;
	}
}
function redirectToLoginIfRequired(result) {
	if (!isLoginRequired(result)) return false;
	const url = result.loginUrl;
	if (!url) return false;
	if (typeof window === "undefined") return false;
	if (isFramed()) {
		const opened = window.open(url, "_blank");
		if (opened) {
			opened.opener = null;
			return true;
		}
	}
	window.location.assign(url);
	return true;
}
function previewKind(file) {
	if (file.type.startsWith("image/") || /\.(png|jpe?g|webp|gif)$/i.test(file.name)) return "image";
	if (file.type === "application/pdf" || /\.pdf$/i.test(file.name)) return "pdf";
	return null;
}
function FilesPanel({ packetId, kind, answers, set }) {
	const packet = useDesk((state) => state.packets.find((item) => item.id === packetId));
	const addFiles = useDesk((state) => state.addFiles);
	const updateAnswer = useDesk((state) => state.updateAnswer);
	const removeFile = useDesk((state) => state.removeFile);
	const files = packet ? packetFiles(packet) : [];
	const groups = docGroups(kind);
	const [error, setError] = (0, import_react.useState)("");
	const [preview, setPreview] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!preview) return;
		function onKey(event) {
			if (event.key === "Escape") closePreview();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [preview]);
	function closePreview() {
		setPreview((current) => {
			if (current) URL.revokeObjectURL(current.url);
			return null;
		});
	}
	async function attach(slot, list) {
		setError("");
		const { added, errors } = await storeIncoming(packetId, slot, list, files);
		if (added.length) {
			addFiles(packetId, added);
			if (slot !== "other") updateAnswer(packetId, slot, "1");
		}
		setError(errors[0] ?? "");
	}
	async function openFile(file) {
		const blob = await getBlob(file.id);
		if (!blob) {
			setError(`${file.name} is no longer stored in this browser.`);
			return;
		}
		const mode = previewKind(file);
		if (!mode) {
			saveBlob(blob, file.name);
			return;
		}
		setPreview((current) => {
			if (current) URL.revokeObjectURL(current.url);
			return {
				url: URL.createObjectURL(blob),
				file,
				kind: mode
			};
		});
	}
	async function saveFile(file) {
		const blob = await getBlob(file.id);
		if (!blob) {
			setError(`${file.name} is no longer stored in this browser.`);
			return;
		}
		saveBlob(blob, file.name);
	}
	function dropFile(file) {
		removeFile(packetId, file.id);
		deleteBlob(file.id);
	}
	const known = new Set(groups.flatMap((group) => group.items.map((item) => item.key)));
	const other = files.filter((file) => file.slot === "other" || !known.has(file.slot));
	const intro = groups.length > 0 ? "Check a line to mark it on the voucher. Attach the file itself so the downloaded packet includes it." : "Attach the check copy, wire advice, or the earlier voucher this payment follows.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink-soft",
				children: intro
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-red-deep",
				role: "alert",
				children: error
			}) : null,
			groups.map((group, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: group.title,
				eyebrow: index === 0 ? "Backup with the voucher" : void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocRow, {
						label: item.label,
						checked: answers[item.key] === "1",
						files: files.filter((file) => file.slot === item.key),
						onToggle: (on) => set(item.key, on ? "1" : ""),
						onAttach: (list) => void attach(item.key, list),
						onOpen: (file) => void openFile(file),
						onSave: (file) => void saveFile(file),
						onRemove: dropFile
					}, item.key))
				})
			}, group.title)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: groups.length ? "Other backup" : "Backup files",
				eyebrow: groups.length ? void 0 : "Kept with this packet",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OtherDrop, {
					files: other,
					onAttach: (list) => void attach("other", list),
					onOpen: (file) => void openFile(file),
					onSave: (file) => void saveFile(file),
					onRemove: dropFile
				})
			}),
			preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex flex-col bg-ink/50 p-3 sm:p-6",
				onClick: closePreview,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex min-h-0 w-full max-w-3xl flex-1 flex-col overflow-hidden rounded-lg border border-line bg-card",
					onClick: (event) => event.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 border-b border-line px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "min-w-0 flex-1 truncate text-sm font-semibold",
								children: preview.file.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex h-11 items-center rounded-md border border-line-strong px-3 text-sm font-semibold",
								onClick: () => void saveFile(preview.file),
								children: "Download"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex size-11 items-center justify-center rounded-md border border-line",
								"aria-label": "Close preview",
								onClick: closePreview,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
									className: "size-4",
									"aria-hidden": "true"
								})
							})
						]
					}), preview.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: preview.url,
						alt: "",
						className: "min-h-0 flex-1 bg-paper object-contain"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						title: preview.file.name,
						src: preview.url,
						className: "min-h-0 w-full flex-1 bg-paper"
					})]
				})
			}) : null
		]
	});
}
function DocRow({ label, checked, files, onToggle, onAttach, onOpen, onSave, onRemove }) {
	const [over, setOver] = (0, import_react.useState)(false);
	const hot = checked || files.length > 0 || over;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		onDragOver: (event) => {
			event.preventDefault();
			setOver(true);
		},
		onDragLeave: () => setOver(false),
		onDrop: (event) => {
			event.preventDefault();
			setOver(false);
			if (event.dataTransfer.files.length) onAttach(event.dataTransfer.files);
		},
		className: `rounded-md border px-3 py-2 ${hot ? "border-red bg-red-soft" : "border-line bg-card"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 flex-1 items-start gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked,
					onChange: (event) => onToggle(event.target.checked),
					className: "mt-1 size-4 accent-red"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [label, files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-xs text-muted",
					children: "No file attached"
				}) : null] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttachButton, {
				label: `Attach ${label}`,
				onAttach
			})]
		}), files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-1 grid gap-1",
			children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileLine, {
				file,
				onOpen,
				onSave,
				onRemove
			}, file.id))
		}) : null]
	});
}
function OtherDrop({ files, onAttach, onOpen, onSave, onRemove }) {
	const [over, setOver] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		onDragOver: (event) => {
			event.preventDefault();
			setOver(true);
		},
		onDragLeave: () => setOver(false),
		className: `rounded-md border border-dashed px-4 py-5 text-center ${over ? "border-red bg-red-soft" : "border-line-strong bg-paper"}`,
		onDrop: (event) => {
			event.preventDefault();
			setOver(false);
			if (event.dataTransfer.files.length) onAttach(event.dataTransfer.files);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, {
				className: "mx-auto size-5 text-red",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm font-medium",
				children: "Drop extra backup here"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "PDF, image, Word, Excel, or text. 12 MB each."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttachButton, {
					label: "Choose files",
					onAttach
				})
			}),
			files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-1 text-left",
				children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileLine, {
					file,
					onOpen,
					onSave,
					onRemove
				}, file.id))
			}) : null
		]
	});
}
function AttachButton({ label, onAttach }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "inline-flex h-11 shrink-0 cursor-pointer items-center rounded-md border border-line-strong bg-card px-3 text-sm font-semibold text-ink",
		children: [label === "Choose files" ? "Choose files" : "Attach", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "file",
			accept: ACCEPT,
			multiple: true,
			className: "sr-only",
			"aria-label": label,
			onChange: (event) => {
				const list = event.target.files;
				if (list && list.length) onAttach(list);
				event.target.value = "";
			}
		})]
	});
}
function FileLine({ file, onOpen, onSave, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-2 rounded-md border border-line bg-card px-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
				className: "size-4 shrink-0 text-red",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 min-w-0 flex-1 truncate text-left text-sm",
				onClick: () => onOpen(file),
				children: file.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 text-xs text-muted tabular-nums",
				children: formatBytes(file.size)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "inline-flex size-11 items-center justify-center text-ink-soft",
				"aria-label": `Download ${file.name}`,
				onClick: () => onSave(file),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
					className: "size-4",
					"aria-hidden": "true"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "inline-flex size-11 items-center justify-center text-ink-soft",
				"aria-label": `Remove ${file.name}`,
				onClick: () => onRemove(file),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
					className: "size-4",
					"aria-hidden": "true"
				})
			})
		]
	});
}
function sectionsFor(kind) {
	if (kind === "lease") return [
		{
			id: "property",
			label: "Property"
		},
		{
			id: "terms",
			label: "Terms"
		},
		{
			id: "docs",
			label: "Documents"
		},
		{
			id: "agents",
			label: "Agents"
		},
		{
			id: "money",
			label: "Commission"
		},
		{
			id: "invoice",
			label: "Invoice"
		},
		{
			id: "sign",
			label: "Sign"
		}
	];
	if (kind === "sale") return [
		{
			id: "property",
			label: "Property"
		},
		{
			id: "docs",
			label: "Documents"
		},
		{
			id: "agents",
			label: "Parties"
		},
		{
			id: "money",
			label: "Commission"
		},
		{
			id: "invoice",
			label: "Invoice"
		},
		{
			id: "sign",
			label: "Sign"
		}
	];
	if (kind === "consult") return [
		{
			id: "property",
			label: "Engagement"
		},
		{
			id: "docs",
			label: "Documents"
		},
		{
			id: "money",
			label: "Commission"
		},
		{
			id: "invoice",
			label: "Invoice"
		},
		{
			id: "sign",
			label: "Sign"
		}
	];
	return [
		{
			id: "property",
			label: "Property"
		},
		{
			id: "money",
			label: "Commission"
		},
		{
			id: "files",
			label: "Files"
		},
		{
			id: "sign",
			label: "Sign"
		}
	];
}
var PROPERTY_TYPES = [
	{
		value: "industrial",
		label: "Industrial"
	},
	{
		value: "land",
		label: "Land"
	},
	{
		value: "office",
		label: "Office"
	},
	{
		value: "retail",
		label: "Retail"
	}
];
function slotCount(answers, prefix, total, minimum) {
	let count = minimum;
	for (let i = 1; i <= total; i += 1) if (Object.keys(answers).some((key) => key.startsWith(`${prefix}${i}`) && answers[key])) count = Math.max(count, i);
	return count;
}
function PropertyBlock({ answers, set, showType }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [showType ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
			label: "Property type",
			value: read(answers, "propertyType"),
			onChange: (value) => set("propertyType", value),
			options: PROPERTY_TYPES
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					className: "sm:col-span-2",
					name: "address",
					label: "Property address",
					value: read(answers, "address"),
					onChange: (value) => set("address", value),
					placeholder: "1400 E Walnut Ave"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "city",
					label: "City, state, ZIP",
					value: read(answers, "city"),
					onChange: (value) => set("city", value),
					placeholder: "Commerce, CA 90040"
				}),
				showType ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "propertyOther",
					label: "Other type",
					value: read(answers, "propertyOther"),
					onChange: (value) => set("propertyOther", value),
					placeholder: "Flex, IOS, medical…"
				}) : null,
				showType ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "sf",
					label: "Square feet",
					value: read(answers, "sf"),
					onChange: (value) => set("sf", value),
					inputMode: "decimal"
				}) : null
			]
		})]
	});
}
function FundsBlock({ answers, set }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
			label: "Type of funds",
			value: read(answers, "fundsType"),
			onChange: (value) => set("fundsType", value),
			options: [
				{
					value: "check",
					label: "Check"
				},
				{
					value: "wire",
					label: "Wire"
				},
				{
					value: "ach",
					label: "ACH"
				}
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					className: "sm:col-span-2",
					name: "fundsFrom",
					label: "Funds received from",
					value: read(answers, "fundsFrom"),
					onChange: (value) => set("fundsFrom", value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "amountReceived",
					label: "Amount received",
					value: read(answers, "amountReceived"),
					onChange: (value) => set("amountReceived", value),
					inputMode: "decimal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "gross",
					label: "Gross to Lee",
					value: read(answers, "gross"),
					onChange: (value) => set("gross", value),
					inputMode: "decimal",
					hint: "House splits are a percent of this number."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "balance",
					label: "Outstanding balance",
					value: read(answers, "balance"),
					onChange: (value) => set("balance", value),
					inputMode: "decimal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "dueDate",
					label: "Due date",
					value: read(answers, "dueDate"),
					onChange: (value) => set("dueDate", value),
					placeholder: "MM/DD/YYYY"
				})
			]
		})]
	});
}
function SplitsBlock({ answers, set }) {
	const [opened, setOpened] = (0, import_react.useState)(() => slotCount(answers, "split", 4, 2));
	const shown = Math.max(opened, slotCount(answers, "split", 4, 1));
	const percent = splitPercentTotal(answers);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			Number.isFinite(percent) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: `text-sm ${Math.abs(percent - 100) > .2 ? "text-red-deep" : "text-ink-soft"}`,
				children: [
					"Internal splits add up to ",
					percent,
					"% of gross."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: Array.from({ length: shown }, (_, index) => {
					const n = index + 1;
					const net = splitNet(answers.gross, answers[`split${n}Pct`]);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-line bg-paper p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-3 text-xs font-semibold uppercase tracking-widest text-muted",
								children: ["Agent ", n]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										name: `split${n}Agent`,
										label: "Agent",
										value: read(answers, `split${n}Agent`),
										onChange: (value) => set(`split${n}Agent`, value)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										name: `split${n}Entity`,
										label: "Entity",
										value: read(answers, `split${n}Entity`),
										onChange: (value) => set(`split${n}Entity`, value)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										name: `split${n}Pct`,
										label: "% of gross",
										value: read(answers, `split${n}Pct`),
										onChange: (value) => set(`split${n}Pct`, value),
										inputMode: "decimal"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-ink-soft",
										children: "Net commission"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-lg font-medium tabular-nums text-ink",
										children: net ? `$${net}` : "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										name: `split${n}Runner`,
										label: "Runner",
										value: read(answers, `split${n}Runner`),
										onChange: (value) => set(`split${n}Runner`, value)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										name: `split${n}RunnerAmt`,
										label: "Runner check",
										value: read(answers, `split${n}RunnerAmt`),
										onChange: (value) => set(`split${n}RunnerAmt`, value),
										inputMode: "decimal"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 flex min-h-11 items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: answers[`split${n}Defer`] === "1",
									onChange: (event) => set(`split${n}Defer`, event.target.checked ? "1" : ""),
									className: "size-4 accent-red"
								}), "Defer this split"]
							})
						]
					}, n);
				})
			}),
			shown < 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
				onClick: () => setOpened(shown + 1),
				children: "Add another agent"
			}) : null
		]
	});
}
function ExternalBlock({ answers, set }) {
	const [opened, setOpened] = (0, import_react.useState)(() => slotCount(answers, "ext", 2, 1));
	const shown = Math.max(opened, slotCount(answers, "ext", 2, 1));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [Array.from({ length: shown }, (_, index) => {
			const n = index + 1;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md border border-line p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: `Outside company ${n}`,
					value: read(answers, `ext${n}License`),
					onChange: (value) => set(`ext${n}License`, value),
					options: [{
						value: "licensed",
						label: "Licensed"
					}, {
						value: "unlicensed",
						label: "Unlicensed"
					}]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}Company`,
							label: "Company",
							value: read(answers, `ext${n}Company`),
							onChange: (value) => set(`ext${n}Company`, value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}Contact`,
							label: "Contact",
							value: read(answers, `ext${n}Contact`),
							onChange: (value) => set(`ext${n}Contact`, value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							className: "sm:col-span-2",
							name: `ext${n}Address`,
							label: "Address",
							value: read(answers, `ext${n}Address`),
							onChange: (value) => set(`ext${n}Address`, value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}City`,
							label: "City, state, ZIP",
							value: read(answers, `ext${n}City`),
							onChange: (value) => set(`ext${n}City`, value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}Email`,
							label: "Email",
							value: read(answers, `ext${n}Email`),
							onChange: (value) => set(`ext${n}Email`, value),
							inputMode: "email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}Area`,
							label: "Area code",
							value: read(answers, `ext${n}Area`),
							onChange: (value) => set(`ext${n}Area`, value),
							inputMode: "tel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}Phone`,
							label: "Phone",
							value: read(answers, `ext${n}Phone`),
							onChange: (value) => set(`ext${n}Phone`, value),
							inputMode: "tel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}Corp`,
							label: "Corp. DRE #",
							value: read(answers, `ext${n}Corp`),
							onChange: (value) => set(`ext${n}Corp`, value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}Sales`,
							label: "Salesperson DRE #",
							value: read(answers, `ext${n}Sales`),
							onChange: (value) => set(`ext${n}Sales`, value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: `ext${n}Commission`,
							label: "Commission amount",
							value: read(answers, `ext${n}Commission`),
							onChange: (value) => set(`ext${n}Commission`, value),
							inputMode: "decimal"
						})
					]
				})]
			}, n);
		}), shown < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
			onClick: () => setOpened(2),
			children: "Add second outside company"
		}) : null]
	});
}
function AgentPairs({ answers, set, prefix, title }) {
	const [opened, setOpened] = (0, import_react.useState)(() => slotCount(answers, prefix, 3, 1));
	const shown = Math.max(opened, slotCount(answers, prefix, 3, 1));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mb-3 font-serif text-xl",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3",
			children: Array.from({ length: shown }, (_, index) => {
				const n = index + 1;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: `${prefix}${n}Name`,
						label: `Agent ${n}`,
						value: read(answers, `${prefix}${n}Name`),
						onChange: (value) => set(`${prefix}${n}Name`, value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: `${prefix}${n}Firm`,
						label: "Firm",
						value: read(answers, `${prefix}${n}Firm`),
						onChange: (value) => set(`${prefix}${n}Firm`, value)
					})]
				}, n);
			})
		}),
		shown < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
			className: "mt-3",
			onClick: () => setOpened(shown + 1),
			children: "Add agent"
		}) : null
	] });
}
function MarketingBlock({ answers, set }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checks, {
				answers,
				onChange: set,
				items: [
					{
						key: "mktGift",
						label: "Gift basket"
					},
					{
						key: "mktPress",
						label: "Press release"
					},
					{
						key: "mktWeb",
						label: "Add to website / online resume"
					},
					{
						key: "mktSign",
						label: "Remove sign"
					},
					{
						key: "mktCard",
						label: "Postcard"
					},
					{
						key: "mktLeepro",
						label: "Add to LeePro transaction summary"
					}
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "mktCriteria",
					label: "Postcard criteria",
					value: read(answers, "mktCriteria"),
					onChange: (value) => set("mktCriteria", value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "mktRef",
					label: "Reference contact",
					value: read(answers, "mktRef"),
					onChange: (value) => set("mktRef", value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "highlights",
				label: "Highlights",
				multiline: true,
				value: read(answers, "highlights"),
				onChange: (value) => set("highlights", value)
			})
		]
	});
}
function BillBlock({ answers, set }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "billName",
				label: "Invoice name",
				value: read(answers, "billName"),
				onChange: (value) => set("billName", value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "billCompany",
				label: "Invoice company",
				value: read(answers, "billCompany"),
				onChange: (value) => set("billCompany", value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				className: "sm:col-span-2",
				name: "billCity",
				label: "Invoice city, state, ZIP",
				value: read(answers, "billCity"),
				onChange: (value) => set("billCity", value)
			})
		]
	});
}
function OfficeBlock({ answers, set }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "rounded-md border border-line bg-paper px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
			className: "min-h-11 cursor-pointer text-sm font-medium text-ink-soft",
			children: "Office use only"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 pb-2 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "officeSl",
					label: "S & L #",
					value: read(answers, "officeSl"),
					onChange: (value) => set("officeSl", value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "officeEntered",
					label: "Entered",
					value: read(answers, "officeEntered"),
					onChange: (value) => set("officeEntered", value),
					placeholder: "MM/DD/YYYY"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "officePaid",
					label: "Paid",
					value: read(answers, "officePaid"),
					onChange: (value) => set("officePaid", value),
					placeholder: "MM/DD/YYYY"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "officeCommerce",
					label: "Commerce",
					value: read(answers, "officeCommerce"),
					onChange: (value) => set("officeCommerce", value)
				})
			]
		})]
	});
}
function SignBlock({ answers, set, extra }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-ink-soft",
				children: [
					"I certify that the information in this voucher is true and correct to the best of my knowledge.",
					extra ? ` ${extra}` : "",
					" Typing a name places it on the signature line of the PDF. The broker can still sign the paper copy."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "agentSign",
					label: "Agent signature",
					value: read(answers, "agentSign"),
					onChange: (value) => set("agentSign", value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					name: "brokerSign",
					label: "Broker signature",
					value: read(answers, "brokerSign"),
					onChange: (value) => set("brokerSign", value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "comments",
				label: "Comments",
				multiline: true,
				value: read(answers, "comments"),
				onChange: (value) => set("comments", value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfficeBlock, {
				answers,
				set
			})
		]
	});
}
function RentSchedule({ answers, set }) {
	const math = leaseMath(answers);
	let base = 3;
	math.rows.forEach((row, index) => {
		if (row.active) base = Math.max(base, index + 1);
	});
	const [opened, setOpened] = (0, import_react.useState)(base);
	const shown = Math.max(opened, base);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink-soft",
				children: "Each row prints on page 3. Subtotal is rent times months. Commission is that subtotal times the percent."
			}),
			Array.from({ length: shown }, (_, index) => {
				const n = index + 1;
				const row = math.rows[index];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border border-line p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-2 text-xs font-semibold uppercase tracking-widest text-muted",
						children: ["Period ", n]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: `row${n}From`,
								label: "Mos from",
								value: read(answers, `row${n}From`),
								onChange: (value) => set(`row${n}From`, value),
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: `row${n}To`,
								label: "Mos to",
								value: read(answers, `row${n}To`),
								onChange: (value) => set(`row${n}To`, value),
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: `row${n}Rent`,
								label: "$ / month",
								value: read(answers, `row${n}Rent`),
								onChange: (value) => set(`row${n}Rent`, value),
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: `row${n}Months`,
								label: "Months",
								value: read(answers, `row${n}Months`),
								onChange: (value) => set(`row${n}Months`, value),
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: `row${n}Pct`,
								label: "%",
								value: read(answers, `row${n}Pct`),
								onChange: (value) => set(`row${n}Pct`, value),
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-2 sm:col-span-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-ink-soft",
										children: "Commission"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 tabular-nums font-medium",
										children: row && Number.isFinite(row.commission) ? dollars(row.commission) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted tabular-nums",
										children: row && Number.isFinite(row.subtotal) ? `${dollars(row.subtotal)} consideration` : " "
									})
								]
							})
						]
					})]
				}, n);
			}),
			shown < 10 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
				onClick: () => setOpened(shown + 1),
				children: "Add rent period"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-6 border-t border-line pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm text-ink-soft",
					children: "Total consideration"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-serif text-2xl tabular-nums",
					children: math.any ? dollars(math.consideration) : "—"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm text-ink-soft",
					children: "Total commission"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-serif text-2xl tabular-nums",
					children: math.any ? dollars(math.commission) : "—"
				})] })]
			})
		]
	});
}
function VoucherSection({ packetId, kind, section, answers, set }) {
	if (section === "property") {
		if (kind === "lease") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			eyebrow: "Deal voucher",
			title: "Lease property",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Transaction",
					value: read(answers, "transaction"),
					onChange: (value) => set("transaction", value),
					options: [
						{
							value: "lease",
							label: "Lease"
						},
						{
							value: "sublease",
							label: "Sublease"
						},
						{
							value: "renewal",
							label: "Lease renewal"
						}
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertyBlock, {
					answers,
					set,
					showType: true
				})]
			})
		});
		if (kind === "consult") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			eyebrow: "Deal voucher",
			title: "Consulting or referral",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Engagement",
					value: read(answers, "engagement"),
					onChange: (value) => set("engagement", value),
					options: [{
						value: "referral",
						label: "Referral"
					}, {
						value: "consulting",
						label: "Consulting"
					}]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertyBlock, {
					answers,
					set,
					showType: true
				})]
			})
		});
		if (kind === "additional") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			eyebrow: "Additional payment",
			title: "Property and parties",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertyBlock, {
					answers,
					set,
					showType: false
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Parties, {
					answers,
					set,
					left: "seller",
					right: "buyer",
					leftTitle: "Seller / lessor",
					rightTitle: "Buyer / lessee"
				})]
			})
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			eyebrow: "Deal voucher",
			title: "Sale property",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertyBlock, {
						answers,
						set,
						showType: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: "asking",
								label: "Asking price",
								value: read(answers, "asking"),
								onChange: (value) => set("asking", value),
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: "price",
								label: "Purchase price",
								value: read(answers, "price"),
								onChange: (value) => set("price", value),
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: "closeDate",
								label: "Close of escrow",
								value: read(answers, "closeDate"),
								onChange: (value) => set("closeDate", value),
								placeholder: "MM/DD/YYYY"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Buyer type",
								value: read(answers, "buyerType"),
								onChange: (value) => set("buyerType", value),
								options: [{
									value: "user",
									label: "User"
								}, {
									value: "investor",
									label: "Investor"
								}]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: "saleNotes",
						label: "Sale comments",
						multiline: true,
						value: read(answers, "saleNotes"),
						onChange: (value) => set("saleNotes", value)
					})
				]
			})
		});
	}
	if (section === "terms" && kind === "lease") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Parties",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Parties, {
						answers,
						set,
						left: "lessor",
						right: "lessee",
						leftTitle: "Lessor",
						rightTitle: "Lessee"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "Lee represented",
						value: read(answers, "represented"),
						onChange: (value) => set("represented", value),
						options: [
							{
								value: "lessor",
								label: "Lessor"
							},
							{
								value: "lessee",
								label: "Lessee"
							},
							{
								value: "both",
								label: "Both"
							}
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Lease economics",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "leaseFrom",
							label: "Lease terms from",
							value: read(answers, "leaseFrom"),
							onChange: (value) => set("leaseFrom", value),
							placeholder: "MM/DD/YYYY"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "leaseThrough",
							label: "Through",
							value: read(answers, "leaseThrough"),
							onChange: (value) => set("leaseThrough", value),
							placeholder: "MM/DD/YYYY"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "executionDate",
							label: "Execution date",
							value: read(answers, "executionDate"),
							onChange: (value) => set("executionDate", value),
							placeholder: "MM/DD/YYYY"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "termMos",
							label: "Term (months)",
							value: read(answers, "termMos"),
							onChange: (value) => set("termMos", value),
							inputMode: "decimal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "leasedSf",
							label: "Leased SF",
							value: read(answers, "leasedSf"),
							onChange: (value) => set("leasedSf", value),
							inputMode: "decimal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "buildingSf",
							label: "Total building SF",
							value: read(answers, "buildingSf"),
							onChange: (value) => set("buildingSf", value),
							inputMode: "decimal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "landSf",
							label: "Land SF",
							value: read(answers, "landSf"),
							onChange: (value) => set("landSf", value),
							inputMode: "decimal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "officeSf",
							label: "Office SF",
							value: read(answers, "officeSf"),
							onChange: (value) => set("officeSf", value),
							inputMode: "decimal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "askingRate",
							label: "Asking rate",
							value: read(answers, "askingRate"),
							onChange: (value) => set("askingRate", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "askingType",
							label: "Asking rate type",
							value: read(answers, "askingType"),
							onChange: (value) => set("askingType", value),
							placeholder: "NNN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "leaseRate",
							label: "Lease rate",
							value: read(answers, "leaseRate"),
							onChange: (value) => set("leaseRate", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "leaseType",
							label: "Lease rate type",
							value: read(answers, "leaseType"),
							onChange: (value) => set("leaseType", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "effectiveRate",
							label: "Effective rate",
							value: read(answers, "effectiveRate"),
							onChange: (value) => set("effectiveRate", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "effectiveType",
							label: "Effective rate type",
							value: read(answers, "effectiveType"),
							onChange: (value) => set("effectiveType", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "considerationNote",
							label: "Total consideration note",
							value: read(answers, "considerationNote"),
							onChange: (value) => set("considerationNote", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "ti",
							label: "TI allowance",
							value: read(answers, "ti"),
							onChange: (value) => set("ti", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "leaseOption",
							label: "Lease option terms",
							value: read(answers, "leaseOption"),
							onChange: (value) => set("leaseOption", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "purchaseOption",
							label: "Purchase option terms",
							value: read(answers, "purchaseOption"),
							onChange: (value) => set("purchaseOption", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "exerciseLeft",
							label: "Exercise time frame",
							value: read(answers, "exerciseLeft"),
							onChange: (value) => set("exerciseLeft", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							name: "freeRent",
							label: "Free rent",
							value: read(answers, "freeRent"),
							onChange: (value) => set("freeRent", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							className: "sm:col-span-2",
							name: "nnn",
							label: "NNN / CAM charges",
							value: read(answers, "nnn"),
							onChange: (value) => set("nnn", value)
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Escalations",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [Array.from({ length: 5 }, (_, index) => {
						const n = index + 1;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									name: `esc${n}Period`,
									label: `Period ${n}`,
									value: read(answers, `esc${n}Period`),
									onChange: (value) => set(`esc${n}Period`, value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									name: `esc${n}Psf`,
									label: "Rate PSF",
									value: read(answers, `esc${n}Psf`),
									onChange: (value) => set(`esc${n}Psf`, value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									name: `esc${n}Type`,
									label: "Rate type",
									value: read(answers, `esc${n}Type`),
									onChange: (value) => set(`esc${n}Type`, value)
								})
							]
						}, n);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: "escNotes",
						label: "Escalation comments",
						multiline: true,
						value: read(answers, "escNotes"),
						onChange: (value) => set("escNotes", value)
					})]
				})
			})
		]
	});
	if (section === "docs" || section === "files") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesPanel, {
		packetId,
		kind,
		answers,
		set
	});
	if (section === "agents") {
		if (kind === "sale") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Seller and buyer",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Parties, {
					answers,
					set,
					left: "seller",
					right: "buyer",
					leftTitle: "Seller",
					rightTitle: "Buyer"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Brokers",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentPairs, {
						answers,
						set,
						prefix: "list",
						title: "Listing agents"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentPairs, {
						answers,
						set,
						prefix: "proc",
						title: "Procuring agents"
					})]
				})
			})]
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			title: "Listing and procuring",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentPairs, {
					answers,
					set,
					prefix: "list",
					title: "Listing agents"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentPairs, {
					answers,
					set,
					prefix: "proc",
					title: "Procuring agents"
				})]
			})
		});
	}
	if (section === "money") {
		const sale = saleCommission(answers);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					title: "Funds received",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FundsBlock, {
						answers,
						set
					})
				}),
				kind === "sale" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					title: "Commission math",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: "saleBase",
								label: "Consideration in the formula",
								value: read(answers, "saleBase"),
								onChange: (value) => set("saleBase", value),
								placeholder: answers.price || "Purchase price",
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: "salePct",
								label: "Commission %",
								value: read(answers, "salePct"),
								onChange: (value) => set("salePct", value),
								inputMode: "decimal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ink-soft",
								children: "Commission"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-serif text-2xl tabular-nums",
								children: sale.ready ? dollars(sale.line) : "—"
							})] })
						]
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					title: "Internal distribution",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitsBlock, {
						answers,
						set
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					title: "Outside companies",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalBlock, {
						answers,
						set
					})
				}),
				kind === "consult" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					title: "Distribution note",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: "sideComment",
						label: "Comment on the commission page",
						value: read(answers, "sideComment"),
						onChange: (value) => set("sideComment", value)
					})
				}) : null
			]
		});
	}
	if (section === "invoice") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			kind === "lease" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Total consideration",
				eyebrow: "Page 3 of the lease voucher",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RentSchedule, {
					answers,
					set
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Who to invoice",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "Send an invoice?",
						value: read(answers, "invoice"),
						onChange: (value) => set("invoice", value),
						options: [{
							value: "yes",
							label: "Yes"
						}, {
							value: "no",
							label: "No"
						}]
					}), answers.invoice === "yes" || kind !== "consult" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillBlock, {
						answers,
						set
					}) : null]
				})
			}),
			kind === "lease" || kind === "sale" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "Marketing",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketingBlock, {
					answers,
					set
				})
			}) : null
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		title: "Certify and sign",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignBlock, {
			answers,
			set,
			extra: kind === "additional" ? void 0 : "The required backup items marked on the checklist are included in sequential order."
		})
	});
}
function Parties({ answers, set, left, right, leftTitle, rightTitle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Party, {
			answers,
			set,
			prefix: left,
			title: leftTitle
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Party, {
			answers,
			set,
			prefix: right,
			title: rightTitle
		})]
	});
}
function Party({ answers, set, prefix, title }) {
	const nameKey = prefix;
	const dbaKey = `${prefix}Dba`;
	const contactKey = `${prefix}Contact`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 rounded-md border border-line p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: nameKey,
				label: "Name",
				value: read(answers, nameKey),
				onChange: (value) => set(nameKey, value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: dbaKey,
				label: "Company DBA",
				value: read(answers, dbaKey),
				onChange: (value) => set(dbaKey, value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: contactKey,
				label: "Contact",
				value: read(answers, contactKey),
				onChange: (value) => set(contactKey, value)
			})
		]
	});
}
function EditorPage({ id }) {
	const ready = useDeskHydrated();
	const { user, isPending } = useCurrentUserState();
	const { role, pending: memberPending } = useMember();
	const own = useDesk((state) => state.packets.find((item) => item.id === id));
	const [foreign, setForeign] = (0, import_react.useState)(null);
	const [agentName, setAgentName] = (0, import_react.useState)("");
	const [foreignReady, setForeignReady] = (0, import_react.useState)(false);
	const updateAnswer = useDesk((state) => state.updateAnswer);
	const setStatus = useDesk((state) => state.setStatus);
	const defaultEmail = useDesk((state) => state.defaultEmail);
	const setDefaultEmail = useDesk((state) => state.setDefaultEmail);
	const [section, setSection] = (0, import_react.useState)("property");
	const [busy, setBusy] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!ready || memberPending) return;
		if (own || role !== "staff" && role !== "admin") {
			setForeign(null);
			setForeignReady(true);
			return;
		}
		let stop = false;
		setForeignReady(false);
		hydrateSubmitted(id).then((row) => {
			if (stop) return;
			setForeign(row);
			setAgentName(row?.agentName ?? "");
			setForeignReady(true);
		});
		return () => {
			stop = true;
		};
	}, [
		ready,
		memberPending,
		own,
		role,
		id
	]);
	const packet = own ?? foreign;
	const viewOnly = !own && Boolean(foreign);
	if (!ready || isPending || memberPending || !foreignReady) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Opening voucher…"
		})
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!packet) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "This voucher is not on your account"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-ink-soft",
				children: "Drafts follow the agent who signed in, not the browser."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 inline-flex h-11 items-center font-semibold text-red",
				children: "Back to Deal Desk"
			})
		]
	});
	const meta = KIND_META[packet.kind];
	const sections = sectionsFor(packet.kind);
	const missing = blockers(packet.kind, packet.answers);
	const files = packetFiles(packet);
	const uncheckedFiles = checkedWithoutFile(packet);
	const active = sections.some((item) => item.id === section) ? section : "property";
	const email = (packet.answers.sendTo ?? defaultEmail).trim();
	const emailOk = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(email);
	const readyToSend = missing.length === 0 && emailOk;
	function onEmailChange(value) {
		if (!packet) return;
		updateAnswer(packet.id, "sendTo", value);
		setDefaultEmail(value.trim());
	}
	function leftOutNote(count) {
		if (count <= 0) return;
		setError(count === 1 ? "1 attached file is no longer in this browser and was left out of the packet." : `${count} attached files are no longer in this browser and were left out of the packet.`);
	}
	async function onDownload() {
		if (!packet) return;
		setBusy("pdf");
		setError("");
		setNote("");
		try {
			await downloadVoucher(packet);
		} catch {
			setError("The PDF could not be built. Try again.");
		} finally {
			setBusy("");
		}
	}
	async function onPacket() {
		if (!packet) return;
		setBusy("packet");
		setError("");
		setNote("");
		try {
			leftOutNote(await downloadPacket(packet));
		} catch {
			setError("The packet could not be built. Try again.");
		} finally {
			setBusy("");
		}
	}
	async function onEmail() {
		if (!packet || !readyToSend) return;
		setBusy("email");
		setError("");
		setNote("");
		try {
			const result = await emailPacket(packet, email);
			setStatus(packet.id, "submitted");
			leftOutNote(result.missing);
			setNote(`Sent to ${email}. The message is the voucher. The PDF and each backup file are attached on their own.`);
		} catch (caught) {
			const failed = caught;
			if (redirectToLoginIfRequired({
				ok: false,
				data: null,
				loginRequired: failed.loginRequired,
				loginUrl: failed.loginUrl
			})) return;
			const raw = (failed.message ?? "").toLowerCase();
			if (failed.pending || raw.includes("connector_token") || raw.includes("not_connected") || raw.includes("missing_connector")) {
				setError("Connect Gmail to send this voucher. Nothing is zipped.");
				return;
			}
			setError(failed.message || "The voucher could not be sent. Try again.");
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-red" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-3xl px-4 py-3 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "inline-flex h-11 shrink-0 items-center gap-2 text-sm font-semibold text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Desk"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-semibold text-ink",
									children: packetTitle(packet)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-xs text-muted",
									children: [
										meta.short,
										" · ",
										packet.status === "submitted" ? "Submitted" : "Draft",
										files.length ? ` · ${files.length} file${files.length === 1 ? "" : "s"}` : ""
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
								className: "shrink-0",
								disabled: busy !== "",
								onClick: () => void onDownload(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									className: "size-4",
									"aria-hidden": "true"
								}), busy === "pdf" ? "Building…" : "PDF"]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-3 flex gap-2 overflow-x-auto",
						"aria-label": "Voucher sections",
						children: sections.map((item) => {
							const needs = missing.some((issue) => issue.section === item.id);
							const selected = item.id === active;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-current": selected ? "page" : void 0,
								onClick: () => {
									setSection(item.id);
									document.getElementById("voucher-form")?.scrollIntoView({ block: "start" });
								},
								className: `h-11 shrink-0 rounded-md border px-3 text-sm font-medium ${selected ? "border-ink bg-ink text-card" : "border-line bg-card text-ink"}`,
								children: [item.label, needs ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ml-2 inline-block size-2 rounded-full bg-red align-middle" }) : null]
							}, item.id);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "voucher-form",
				className: "mx-auto max-w-3xl scroll-mt-36 px-4 py-5 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 flex justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-red",
						children: meta.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-serif text-4xl",
						children: packetTitle(packet)
					}),
					viewOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-ink-soft",
						children: [
							"Submitted by ",
							agentName,
							". Staff can read this voucher and its files. The agent still owns the draft."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 mb-4 grid gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								name: "sendTo",
								label: "Email the packet to",
								value: packet.answers.sendTo ?? defaultEmail,
								onChange: onEmailChange,
								inputMode: "email",
								placeholder: "accounting@example.com"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-ink-soft",
								children: [
									missing.length === 0 ? "Required fields are in." : `Still needs ${missing.map((item) => item.label.toLowerCase()).join(", ")}.`,
									files.length === 0 ? " No backup files attached yet." : ` ${files.length} backup file${files.length === 1 ? "" : "s"} attached.`,
									uncheckedFiles > 0 ? ` ${uncheckedFiles} checked document${uncheckedFiles === 1 ? "" : "s"} still need a file.` : ""
								]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-red-deep",
								children: error
							}) : null,
							note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ink-soft",
								children: note
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [
									viewOnly ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
										disabled: !readyToSend || busy !== "",
										onClick: () => void onEmail(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
											className: "size-4",
											"aria-hidden": "true"
										}), busy === "email" ? "Sending…" : "Send"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
										disabled: busy !== "",
										onClick: () => void onPacket(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderArchive, {
											className: "size-4",
											"aria-hidden": "true"
										}), busy === "packet" ? "Packing…" : "Download packet"]
									}),
									viewOnly ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
										disabled: missing.length > 0 || busy !== "",
										onClick: () => setStatus(packet.id, packet.status === "submitted" ? "draft" : "submitted"),
										children: packet.status === "submitted" ? "Move to drafts" : "Mark submitted"
									})
								]
							}),
							viewOnly ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Send emails the voucher from Gmail. The deal is in the message. The office PDF and each backup file go along separately — no zip to open."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoucherSection, {
						packetId: packet.id,
						kind: packet.kind,
						section: active,
						answers: packet.answers,
						set: (key, value) => updateAnswer(packet.id, key, value)
					})
				]
			})
		]
	});
}
function VoucherRoute() {
	const { id } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorPage, { id });
}
//#endregion
export { VoucherRoute as component, redirectToLoginIfRequired as n, isLoginRequired as t };
