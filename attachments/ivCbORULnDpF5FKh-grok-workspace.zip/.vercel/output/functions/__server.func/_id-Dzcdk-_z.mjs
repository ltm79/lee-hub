import { _ as createFileRoute, g as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-Dzcdk-_z.js
var $$splitComponentImporter = () => import("./_id-3MtoqAQK.mjs");
var Route = createFileRoute("/vouchers/$id")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [{ title: "Voucher · Deal Desk" }] })
});
//#endregion
export { Route as t };
