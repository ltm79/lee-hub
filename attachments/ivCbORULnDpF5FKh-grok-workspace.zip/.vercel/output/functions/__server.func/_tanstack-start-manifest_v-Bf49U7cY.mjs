//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bf49U7cY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/vouchers/$id",
			"/api/auth/$"
		],
		preloads: ["/assets/index-Bz-aXh-W.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bz-aXh-W.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DdePbHrn.js",
			"/assets/ui-BT3-qVn3.js",
			"/assets/gates-BmE0qYZq.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-CiOvH9wk.js", "/assets/ui-BT3-qVn3.js"]
	},
	"/vouchers/$id": {
		filePath: "/workspace/src/routes/vouchers/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-BxvLpykK.js",
			"/assets/ui-BT3-qVn3.js",
			"/assets/gates-BmE0qYZq.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
