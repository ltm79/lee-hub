import { n as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BVAF89CC.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/send-rohGcPeq.js
var EMAIL = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
var MAX_FILES = 16;
var MAX_FILE_CHARS = 9e6;
var MAX_TOTAL_CHARS = 12e6;
function cleanName(name) {
	return (name.split(/[/\\]/).pop() ?? "file").replace(/[^A-Za-z0-9._-]+/g, "-").replace(/-+/g, "-").slice(0, 80) || "file";
}
var sendVoucherEmail_createServerFn_handler = createServerRpc({
	id: "3d4f3b900840631ecdc0cc66258108bd2bd34781c314194210a05b1b2e13dd0c",
	name: "sendVoucherEmail",
	filename: "src/lib/desk/send.ts"
}, (opts) => sendVoucherEmail.__executeServer(opts));
var sendVoucherEmail = createServerFn({ method: "POST" }).validator((data) => data).middleware([authMiddleware]).handler(sendVoucherEmail_createServerFn_handler, async ({ data }) => {
	if (!EMAIL.test(data.to)) return {
		ok: false,
		errorMessage: "Enter a real email address."
	};
	if (!data.subject.trim() || !data.body.trim()) return {
		ok: false,
		errorMessage: "This voucher does not have enough to send."
	};
	if (data.attachments.length > MAX_FILES) return {
		ok: false,
		errorMessage: "Too many files to email at once."
	};
	let total = 0;
	for (const file of data.attachments) {
		if (file.contentBase64.length > MAX_FILE_CHARS) return {
			ok: false,
			errorMessage: `${file.filename} is too large to email.`
		};
		total += file.contentBase64.length;
	}
	if (total > MAX_TOTAL_CHARS) return {
		ok: false,
		errorMessage: "These files are too large to email together. Remove one and send again."
	};
	const { callTool } = await import("./client.server-CNRG5nm6.mjs");
	const { ConnectorType } = await import("./types-zwiRwnPE.mjs").then((n) => n.a);
	const result = await callTool("gmail_send_email", {
		to: data.to,
		subject: data.subject.trim(),
		body: data.body,
		attachments: data.attachments.map((file) => ({
			filename: cleanName(file.filename),
			mimeType: file.mimeType || "application/octet-stream",
			content: file.contentBase64
		}))
	}, { connectorType: ConnectorType.Gmail });
	return {
		ok: result.ok,
		errorMessage: result.errorMessage,
		loginRequired: result.loginRequired,
		loginUrl: result.loginUrl,
		pending: result.pending
	};
});
//#endregion
export { sendVoucherEmail_createServerFn_handler };
