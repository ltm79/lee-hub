import { n as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BVAF89CC.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-DhHs2zh4.js
var KINDS = /* @__PURE__ */ new Set([
	"lease",
	"sale",
	"consult",
	"additional"
]);
var STATUSES = /* @__PURE__ */ new Set(["draft", "submitted"]);
function cleanAnswers(raw) {
	const answers = {};
	if (!raw || typeof raw !== "object") return answers;
	for (const [key, value] of Object.entries(raw)) {
		if (key.length > 40 || typeof value !== "string" || value.length > 4e3 || !value) continue;
		answers[key] = value;
		if (Object.keys(answers).length >= 400) break;
	}
	return answers;
}
function cleanFiles(raw) {
	if (!Array.isArray(raw)) return [];
	const files = [];
	for (const file of raw) {
		if (!file || typeof file.id !== "string" || typeof file.name !== "string") continue;
		files.push({
			id: file.id.slice(0, 80),
			slot: String(file.slot ?? "other").slice(0, 40),
			name: file.name.slice(0, 180),
			type: String(file.type ?? "application/octet-stream").slice(0, 120),
			size: Number.isFinite(file.size) ? Math.max(0, Math.round(file.size)) : 0,
			addedAt: Number.isFinite(file.addedAt) ? file.addedAt : Date.now()
		});
		if (files.length >= 40) break;
	}
	return files;
}
function cleanPacket(input) {
	if (!input || typeof input.id !== "string" || !/^[0-9a-f-]{16,80}$/i.test(input.id)) throw new Error("That voucher cannot be saved.");
	if (!KINDS.has(input.kind) || !STATUSES.has(input.status)) throw new Error("That voucher cannot be saved.");
	return {
		id: input.id,
		kind: input.kind,
		status: input.status,
		createdAt: Number.isFinite(input.createdAt) ? input.createdAt : Date.now(),
		updatedAt: Number.isFinite(input.updatedAt) ? input.updatedAt : Date.now(),
		submittedAt: input.submittedAt,
		answers: cleanAnswers(input.answers),
		files: cleanFiles(input.files)
	};
}
function toPacket(row) {
	return {
		id: row.id,
		kind: row.kind,
		status: row.status,
		createdAt: Number(row.created_at),
		updatedAt: Number(row.updated_at),
		submittedAt: row.submitted_at == null ? void 0 : Number(row.submitted_at),
		answers: row.answers ?? {},
		files: Array.isArray(row.files) ? row.files : []
	};
}
var listDesk_createServerFn_handler = createServerRpc({
	id: "e74c30d9e05d59f1eee8ed99d33b1d114f98aa2482e91f12576ff50e086f56aa",
	name: "listDesk",
	filename: "src/lib/desk/account.ts"
}, (opts) => listDesk.__executeServer(opts));
var listDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listDesk_createServerFn_handler, async ({ context }) => {
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	const rows = await sql`
      select id, kind, status, answers, files, created_at, updated_at, submitted_at
      from desk_packets
      where user_id = ${context.userId}
      order by updated_at desc
    `;
	const settings = await sql`
      select default_email from desk_settings where user_id = ${context.userId}
    `;
	return {
		packets: rows.map(toPacket),
		defaultEmail: settings[0]?.default_email ?? ""
	};
});
var saveDeskPacket_createServerFn_handler = createServerRpc({
	id: "3cf09d261462c953760c432eebba6703ebf63ab69215d3704fb608bfdd29ec38",
	name: "saveDeskPacket",
	filename: "src/lib/desk/account.ts"
}, (opts) => saveDeskPacket.__executeServer(opts));
var saveDeskPacket = createServerFn({ method: "POST" }).validator((input) => cleanPacket(input)).middleware([authMiddleware]).handler(saveDeskPacket_createServerFn_handler, async ({ context, data }) => {
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	const owned = await sql`
      select user_id from desk_packets where id = ${data.id}
    `;
	if (owned[0] && owned[0].user_id !== context.userId) throw new Error("That voucher is not on your account.");
	const answers = JSON.stringify(data.answers);
	const files = JSON.stringify(data.files ?? []);
	await sql`
      insert into desk_packets (id, user_id, kind, status, answers, files, created_at, updated_at, submitted_at)
      values (
        ${data.id},
        ${context.userId},
        ${data.kind},
        ${data.status},
        ${answers}::jsonb,
        ${files}::jsonb,
        ${data.createdAt},
        ${data.updatedAt},
        ${data.submittedAt ?? null}
      )
      on conflict (id) do update set
        kind = excluded.kind,
        status = excluded.status,
        answers = excluded.answers,
        files = excluded.files,
        updated_at = excluded.updated_at,
        submitted_at = excluded.submitted_at
      where desk_packets.user_id = ${context.userId}
    `;
	return { ok: true };
});
var deleteDeskPacket_createServerFn_handler = createServerRpc({
	id: "8be4a52330d87e9641de94e5d5d8db6b0fddca84b2aa6350eeb5d3501d0230d9",
	name: "deleteDeskPacket",
	filename: "src/lib/desk/account.ts"
}, (opts) => deleteDeskPacket.__executeServer(opts));
var deleteDeskPacket = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(deleteDeskPacket_createServerFn_handler, async ({ context, data: id }) => {
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	await sql`delete from desk_files where packet_id = ${id} and user_id = ${context.userId}`;
	await sql`delete from desk_packets where id = ${id} and user_id = ${context.userId}`;
	return { ok: true };
});
var saveDeskEmail_createServerFn_handler = createServerRpc({
	id: "96fdfecdc33eb7b4199998b920dbf9847f5d4958d59da3058dcfa0bb54de6fa6",
	name: "saveDeskEmail",
	filename: "src/lib/desk/account.ts"
}, (opts) => saveDeskEmail.__executeServer(opts));
var saveDeskEmail = createServerFn({ method: "POST" }).validator((email) => email.trim().slice(0, 180)).middleware([authMiddleware]).handler(saveDeskEmail_createServerFn_handler, async ({ context, data }) => {
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	await (await getSql())`
      insert into desk_settings (user_id, default_email)
      values (${context.userId}, ${data})
      on conflict (user_id) do update set default_email = excluded.default_email
    `;
	return { ok: true };
});
var saveDeskFile_createServerFn_handler = createServerRpc({
	id: "518df06f523d0a52b0c8d8d2ae1a557bba3bd37ddfe21c82d13130692d16f5b7",
	name: "saveDeskFile",
	filename: "src/lib/desk/account.ts"
}, (opts) => saveDeskFile.__executeServer(opts));
var saveDeskFile = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(saveDeskFile_createServerFn_handler, async ({ context, data }) => {
	if (!data?.id || !data.packetId || !data.contentBase64) throw new Error("That file cannot be saved.");
	if (data.contentBase64.length > 16e6) throw new Error(`${data.name || "A file"} is too large to keep on the account.`);
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	if (!(await sql`
      select id from desk_packets where id = ${data.packetId} and user_id = ${context.userId}
    `)[0]) throw new Error("Save the voucher before its files.");
	const owned = await sql`select user_id from desk_files where id = ${data.id}`;
	if (owned[0] && owned[0].user_id !== context.userId) throw new Error("That file is not on your account.");
	await sql`
      insert into desk_files (id, packet_id, user_id, name, mime, slot, bytes)
      values (
        ${data.id.slice(0, 80)},
        ${data.packetId},
        ${context.userId},
        ${data.name.slice(0, 180)},
        ${(data.mime || "application/octet-stream").slice(0, 120)},
        ${(data.slot || "other").slice(0, 40)},
        decode(${data.contentBase64}, 'base64')
      )
      on conflict (id) do update set
        name = excluded.name,
        mime = excluded.mime,
        slot = excluded.slot,
        bytes = excluded.bytes
      where desk_files.user_id = ${context.userId}
    `;
	return { ok: true };
});
var deleteDeskFile_createServerFn_handler = createServerRpc({
	id: "eee19710a95440130c4c249fd1bcab6c334b364702e9734fb4e3a9c76e9b091c",
	name: "deleteDeskFile",
	filename: "src/lib/desk/account.ts"
}, (opts) => deleteDeskFile.__executeServer(opts));
var deleteDeskFile = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(deleteDeskFile_createServerFn_handler, async ({ context, data: id }) => {
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	await (await getSql())`delete from desk_files where id = ${id} and user_id = ${context.userId}`;
	return { ok: true };
});
var fetchDeskFile_createServerFn_handler = createServerRpc({
	id: "50efc53b1d699657dd5a251ebcb5af2ad5d2a59d8338713549b17a627baa78c1",
	name: "fetchDeskFile",
	filename: "src/lib/desk/account.ts"
}, (opts) => fetchDeskFile.__executeServer(opts));
var fetchDeskFile = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(fetchDeskFile_createServerFn_handler, async ({ context, data: id }) => {
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const row = (await (await getSql())`
      select f.name, f.mime, encode(f.bytes, 'base64') as content
      from desk_files f
      left join desk_packets p on p.id = f.packet_id
      left join desk_members me on me.user_id = ${context.userId}
      where f.id = ${id}
        and (
          f.user_id = ${context.userId}
          or (me.active and me.role in ('staff', 'admin') and p.status = 'submitted')
        )
    `)[0];
	if (!row) return null;
	return {
		name: row.name,
		mime: row.mime,
		contentBase64: row.content
	};
});
//#endregion
export { deleteDeskFile_createServerFn_handler, deleteDeskPacket_createServerFn_handler, fetchDeskFile_createServerFn_handler, listDesk_createServerFn_handler, saveDeskEmail_createServerFn_handler, saveDeskFile_createServerFn_handler, saveDeskPacket_createServerFn_handler };
