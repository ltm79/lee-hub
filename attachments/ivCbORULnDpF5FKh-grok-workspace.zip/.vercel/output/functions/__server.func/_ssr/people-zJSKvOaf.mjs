import { n as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BVAF89CC.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/people-zJSKvOaf.js
var ADMIN_USERNAME = "admin";
var ADMIN_PASSWORD = "DealDesk-Admin-1";
var DOMAIN = "desk.local";
function loginEmail(username) {
	return `${username.trim().toLowerCase()}@${DOMAIN}`;
}
function cleanUsername(value) {
	const username = value.trim().toLowerCase();
	if (!/^[a-z][a-z0-9._-]{1,31}$/.test(username)) throw new Error("Usernames start with a letter and use letters, numbers, dots, or dashes.");
	return username;
}
function asMember(row) {
	const role = row.role === "admin" || row.role === "staff" ? row.role : "agent";
	return {
		userId: row.user_id,
		username: row.username,
		name: row.name,
		role,
		active: Boolean(row.active)
	};
}
async function ensureAdmin() {
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const { hashPassword } = await import("./crypto-QVkT-fgq.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	if ((await sql`
    select user_id from desk_members where role = 'admin' limit 1
  `)[0]) return;
	const id = crypto.randomUUID();
	const accountId = crypto.randomUUID();
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const hash = await hashPassword(ADMIN_PASSWORD);
	await sql`
    insert into "user" ("id", "name", "email", "emailVerified", "createdAt", "updatedAt")
    values (${id}, 'Desk admin', ${loginEmail(ADMIN_USERNAME)}, true, ${now}, ${now})
  `;
	await sql`
    insert into "account" ("id", "accountId", "providerId", "userId", "password", "createdAt", "updatedAt")
    values (${accountId}, ${id}, 'credential', ${id}, ${hash}, ${now}, ${now})
  `;
	await sql`
    insert into desk_members (user_id, username, name, role, active)
    values (${id}, ${ADMIN_USERNAME}, 'Desk admin', 'admin', true)
    on conflict (username) do nothing
  `;
}
async function caller(userId) {
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const rows = await (await getSql())`
    select user_id, username, name, role, active from desk_members where user_id = ${userId}
  `;
	return rows[0] ? asMember(rows[0]) : null;
}
async function requireOffice(userId, roles) {
	const me = await caller(userId);
	if (!me || !me.active || !roles.includes(me.role)) throw new Error("You cannot do that.");
	return me;
}
var prepareDesk_createServerFn_handler = createServerRpc({
	id: "f326178d29573eda510c9509db2e373b48cf0ee36a73ecadc273d1a5b65b6720",
	name: "prepareDesk",
	filename: "src/lib/desk/people.ts"
}, (opts) => prepareDesk.__executeServer(opts));
var prepareDesk = createServerFn({ method: "POST" }).handler(prepareDesk_createServerFn_handler, async () => {
	await ensureAdmin();
	return { ok: true };
});
var whoAmI_createServerFn_handler = createServerRpc({
	id: "7dc1e92a6fe7819fd44852847afc0fc314778b2bf4252d150cb462fd9274778f",
	name: "whoAmI",
	filename: "src/lib/desk/people.ts"
}, (opts) => whoAmI.__executeServer(opts));
var whoAmI = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(whoAmI_createServerFn_handler, async ({ context }) => {
	await ensureAdmin();
	const me = await caller(context.userId);
	if (!me || !me.active) return null;
	return me;
});
var listPeople_createServerFn_handler = createServerRpc({
	id: "526d307d0db9de9c235372db23d17712feb460b5e500b9d66c88a31c15e7fc5f",
	name: "listPeople",
	filename: "src/lib/desk/people.ts"
}, (opts) => listPeople.__executeServer(opts));
var listPeople = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listPeople_createServerFn_handler, async ({ context }) => {
	await requireOffice(context.userId, ["admin"]);
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	return (await (await getSql())`
      select user_id, username, name, role, active from desk_members order by role, username
    `).map(asMember);
});
var createPerson_createServerFn_handler = createServerRpc({
	id: "f703f679bec5ac4faba17db36563b1c3b6fc7c67c5949819623009b66a6c138d",
	name: "createPerson",
	filename: "src/lib/desk/people.ts"
}, (opts) => createPerson.__executeServer(opts));
var createPerson = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createPerson_createServerFn_handler, async ({ context, data }) => {
	await requireOffice(context.userId, ["admin"]);
	const username = cleanUsername(data.username ?? "");
	const name = (data.name ?? "").trim();
	const password = data.password ?? "";
	if (name.length < 2) throw new Error("Add the person's name.");
	if (password.length < 8) throw new Error("Passwords need at least 8 characters.");
	if (data.role !== "agent" && data.role !== "staff") throw new Error("Choose agent or staff.");
	if (username === ADMIN_USERNAME) throw new Error("That username is reserved.");
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const { hashPassword } = await import("./crypto-QVkT-fgq.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	if ((await sql`select username from desk_members where username = ${username}`)[0]) throw new Error("That username is already in use.");
	const id = crypto.randomUUID();
	const accountId = crypto.randomUUID();
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const hash = await hashPassword(password);
	await sql`
      insert into "user" ("id", "name", "email", "emailVerified", "createdAt", "updatedAt")
      values (${id}, ${name.slice(0, 80)}, ${loginEmail(username)}, true, ${now}, ${now})
    `;
	await sql`
      insert into "account" ("id", "accountId", "providerId", "userId", "password", "createdAt", "updatedAt")
      values (${accountId}, ${id}, 'credential', ${id}, ${hash}, ${now}, ${now})
    `;
	await sql`
      insert into desk_members (user_id, username, name, role, active)
      values (${id}, ${username}, ${name.slice(0, 80)}, ${data.role}, true)
    `;
	return { ok: true };
});
var setPersonActive_createServerFn_handler = createServerRpc({
	id: "bab8aa86194c12a1128daf6dc84c17d60e4fcfcb6b9b6180c2f453ec42976161",
	name: "setPersonActive",
	filename: "src/lib/desk/people.ts"
}, (opts) => setPersonActive.__executeServer(opts));
var setPersonActive = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(setPersonActive_createServerFn_handler, async ({ context, data }) => {
	const me = await requireOffice(context.userId, ["admin"]);
	if (data.userId === me.userId) throw new Error("You cannot turn off your own login.");
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	await (await getSql())`
      update desk_members set active = ${Boolean(data.active)}
      where user_id = ${data.userId} and role <> 'admin'
    `;
	return { ok: true };
});
var resetPersonPassword_createServerFn_handler = createServerRpc({
	id: "6ca3d1f5b858bdb233d8c7be21a83677c2088a28a33d9cee14d8bf751b916852",
	name: "resetPersonPassword",
	filename: "src/lib/desk/people.ts"
}, (opts) => resetPersonPassword.__executeServer(opts));
var resetPersonPassword = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(resetPersonPassword_createServerFn_handler, async ({ context, data }) => {
	await requireOffice(context.userId, ["admin"]);
	if ((data.password ?? "").length < 8) throw new Error("Passwords need at least 8 characters.");
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const { hashPassword } = await import("./crypto-QVkT-fgq.mjs").then((n) => n.t).then((n) => n.t);
	await (await getSql())`
      update "account"
      set password = ${await hashPassword(data.password)}, "updatedAt" = ${(/* @__PURE__ */ new Date()).toISOString()}
      where "userId" = ${data.userId} and "providerId" = 'credential'
    `;
	return { ok: true };
});
function toSubmitted(row) {
	return {
		id: row.id,
		kind: row.kind,
		status: row.status,
		createdAt: Number(row.created_at),
		updatedAt: Number(row.updated_at),
		submittedAt: row.submitted_at == null ? void 0 : Number(row.submitted_at),
		answers: row.answers ?? {},
		files: Array.isArray(row.files) ? row.files : [],
		agentName: row.agent_name,
		username: row.username
	};
}
var listSubmitted_createServerFn_handler = createServerRpc({
	id: "cde5b6e5a2de2132936dfe74fb962b48056884f7b57951b9e772bde836aa6262",
	name: "listSubmitted",
	filename: "src/lib/desk/people.ts"
}, (opts) => listSubmitted.__executeServer(opts));
var listSubmitted = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listSubmitted_createServerFn_handler, async ({ context }) => {
	await requireOffice(context.userId, ["admin", "staff"]);
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	return (await (await getSql())`
      select p.id, p.kind, p.status, p.answers, p.files, p.created_at, p.updated_at, p.submitted_at,
             m.name as agent_name, m.username
      from desk_packets p
      join desk_members m on m.user_id = p.user_id
      where p.status = 'submitted'
      order by p.submitted_at desc nulls last, p.updated_at desc
    `).map(toSubmitted);
});
var getSubmitted_createServerFn_handler = createServerRpc({
	id: "457924139a1b2f1d2a36199a5baa7a21421058a0b58f16aa9f08a7741493e514",
	name: "getSubmitted",
	filename: "src/lib/desk/people.ts"
}, (opts) => getSubmitted.__executeServer(opts));
var getSubmitted = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(getSubmitted_createServerFn_handler, async ({ context, data: id }) => {
	await requireOffice(context.userId, ["admin", "staff"]);
	const { getSql } = await import("./db-d17ECXAH.mjs").then((n) => n.t).then((n) => n.t);
	const rows = await (await getSql())`
      select p.id, p.kind, p.status, p.answers, p.files, p.created_at, p.updated_at, p.submitted_at,
             m.name as agent_name, m.username
      from desk_packets p
      join desk_members m on m.user_id = p.user_id
      where p.id = ${id} and p.status = 'submitted'
    `;
	return rows[0] ? toSubmitted(rows[0]) : null;
});
//#endregion
export { createPerson_createServerFn_handler, getSubmitted_createServerFn_handler, listPeople_createServerFn_handler, listSubmitted_createServerFn_handler, prepareDesk_createServerFn_handler, resetPersonPassword_createServerFn_handler, setPersonActive_createServerFn_handler, whoAmI_createServerFn_handler };
