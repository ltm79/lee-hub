import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as createServerFn } from "./ssr.mjs";
import { r as signOut, t as authClient } from "./client-CH2mWUg4.mjs";
import { i as hasGateSessionMarker } from "./env.server-wS9zOhV6.mjs";
import { t as authMiddleware } from "./middleware-BVAF89CC.mjs";
import { _ as whoAmI, c as createSsrRpc, l as getSubmitted } from "./ui-mSmsEGFd.mjs";
import { n as StandardFonts, r as rgb, t as PDFDocument } from "../_libs/pdf-lib.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gates-DYOQ7Lhd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KIND_ORDER = [
	"lease",
	"sale",
	"consult",
	"additional"
];
var KIND_META = {
	lease: {
		title: "Lease voucher",
		short: "Lease",
		pages: "3 pages",
		blurb: "New lease, sublease, or renewal, including the rent schedule."
	},
	sale: {
		title: "Sale voucher",
		short: "Sale",
		pages: "2 pages",
		blurb: "Closed sale, from the document checklist through the invoice."
	},
	consult: {
		title: "Consulting / referral",
		short: "Consulting",
		pages: "2 pages",
		blurb: "Referral or consulting fee with the short backup checklist."
	},
	additional: {
		title: "Additional payment",
		short: "Additional",
		pages: "1 page",
		blurb: "A later check on a deal that already has a voucher on file."
	}
};
function blockers(kind, answers) {
	const out = [];
	if (!answers.address?.trim()) out.push({
		key: "address",
		label: "Property address",
		section: "property"
	});
	if (!answers.city?.trim()) out.push({
		key: "city",
		label: "City, state, ZIP",
		section: "property"
	});
	if (kind === "lease" && !answers.transaction) out.push({
		key: "transaction",
		label: "Lease, sublease, or renewal",
		section: "property"
	});
	if (kind === "consult" && !answers.engagement) out.push({
		key: "engagement",
		label: "Referral or consulting",
		section: "property"
	});
	if (!answers.agentSign?.trim()) out.push({
		key: "agentSign",
		label: "Agent signature",
		section: "sign"
	});
	return out;
}
function packetTitle(packet) {
	return packet.answers.address?.trim() || "Untitled property";
}
var LEASE_DOCS = [
	"Executed lease",
	"Property information sheet",
	"Lee & Associates disclosure",
	"Agency disclosure",
	"Listing agreement",
	"Offer / counter offer",
	"Finder's fee agreement"
];
var SUBLEASE_DOCS = [
	"Executed sublease",
	"Master lessor consent",
	"Master lease",
	"Property information sheet",
	"Lee & Associates disclosure",
	"Agency disclosure",
	"Listing agreement",
	"Offer / counter offer",
	"Finder's fee agreement"
];
var SALE_DOCS = [
	[2, "Final closing statement"],
	[3, "Escrow instructions / amendments"],
	[4, "Purchase and sale agreement"],
	[5, "Property information sheet"],
	[6, "Seller's mandatory disclosure"],
	[7, "Lee & Associates disclosure"],
	[8, "Agency disclosure"],
	[9, "NHDS report"],
	[10, "Preliminary title report"],
	[11, "Environmental / engineering reports"],
	[12, "Earthquake report (pre-1975)"],
	[13, "Listing agreement"],
	[14, "Offer / counter offer"],
	[15, "Finder's fee agreement"]
].map(([id, label]) => ({
	key: `checkSale${id}`,
	label
}));
function numbered(prefix, labels) {
	return labels.map((label, index) => ({
		key: `${prefix}${index + 1}`,
		label
	}));
}
function docGroups(kind) {
	if (kind === "lease") return [
		{
			title: "Lease file",
			items: numbered("checkLease", LEASE_DOCS)
		},
		{
			title: "Sublease file",
			items: numbered("checkSub", SUBLEASE_DOCS)
		},
		{
			title: "Renewal file",
			items: [{
				key: "checkRen1",
				label: "Executed amendment / letter"
			}, {
				key: "checkRen2",
				label: "Finder's fee agreement"
			}]
		}
	];
	if (kind === "sale") return [{
		title: "Sale file",
		items: SALE_DOCS
	}];
	if (kind === "consult") return [{
		title: "Consulting",
		items: [{
			key: "checkCon1",
			label: "Compensation letter from client"
		}, {
			key: "checkCon2",
			label: "Finder's fee agreement"
		}]
	}, {
		title: "Referral",
		items: [
			{
				key: "checkRef1",
				label: "Letter describing the transaction"
			},
			{
				key: "checkRef2",
				label: "Letter disclosing a non-agency transaction"
			},
			{
				key: "checkRef3",
				label: "Finder's fee agreement"
			}
		]
	}];
	return [];
}
function slotLabel(kind, slot) {
	if (slot === "other") return "Other";
	for (const group of docGroups(kind)) {
		const hit = group.items.find((item) => item.key === slot);
		if (hit) return hit.label;
	}
	return "File";
}
function packetFiles(packet) {
	return packet.files ?? [];
}
function checkedWithoutFile(packet) {
	const attached = new Set(packetFiles(packet).map((file) => file.slot));
	let missing = 0;
	for (const group of docGroups(packet.kind)) for (const item of group.items) if (packet.answers[item.key] === "1" && !attached.has(item.key)) missing += 1;
	return missing;
}
var CRC_TABLE = (() => {
	const table = /* @__PURE__ */ new Uint32Array(256);
	for (let n = 0; n < 256; n += 1) {
		let crc = n;
		for (let k = 0; k < 8; k += 1) crc = crc & 1 ? 3988292384 ^ crc >>> 1 : crc >>> 1;
		table[n] = crc >>> 0;
	}
	return table;
})();
function crc32(data) {
	let crc = 4294967295;
	for (let i = 0; i < data.length; i += 1) crc = CRC_TABLE[(crc ^ data[i]) & 255] ^ crc >>> 8;
	return (crc ^ 4294967295) >>> 0;
}
function dosStamp(now) {
	return {
		time: (now.getHours() << 11 | now.getMinutes() << 5 | now.getSeconds() >> 1) & 65535,
		date: (now.getFullYear() - 1980 << 9 | now.getMonth() + 1 << 5 | now.getDate()) & 65535
	};
}
/** Uncompressed ZIP. Deal files are already PDFs and Office documents. */
function zipStore(entries) {
	const { time, date } = dosStamp(/* @__PURE__ */ new Date());
	const encoder = new TextEncoder();
	const locals = [];
	const centrals = [];
	let offset = 0;
	for (const entry of entries) {
		const name = encoder.encode(entry.name);
		const crc = crc32(entry.data);
		const local = new Uint8Array(30 + name.length + entry.data.length);
		const view = new DataView(local.buffer);
		view.setUint32(0, 67324752, true);
		view.setUint16(4, 20, true);
		view.setUint16(8, 0, true);
		view.setUint16(10, time, true);
		view.setUint16(12, date, true);
		view.setUint32(14, crc, true);
		view.setUint32(18, entry.data.length, true);
		view.setUint32(22, entry.data.length, true);
		view.setUint16(26, name.length, true);
		local.set(name, 30);
		local.set(entry.data, 30 + name.length);
		locals.push(local);
		const central = new Uint8Array(46 + name.length);
		const centralView = new DataView(central.buffer);
		centralView.setUint32(0, 33639248, true);
		centralView.setUint16(4, 20, true);
		centralView.setUint16(6, 20, true);
		centralView.setUint16(12, time, true);
		centralView.setUint16(14, date, true);
		centralView.setUint32(16, crc, true);
		centralView.setUint32(20, entry.data.length, true);
		centralView.setUint32(24, entry.data.length, true);
		centralView.setUint16(28, name.length, true);
		centralView.setUint32(42, offset, true);
		central.set(name, 46);
		centrals.push(central);
		offset += local.length;
	}
	const centralSize = centrals.reduce((sum, part) => sum + part.length, 0);
	const end = /* @__PURE__ */ new Uint8Array(22);
	const endView = new DataView(end.buffer);
	endView.setUint32(0, 101010256, true);
	endView.setUint16(8, entries.length, true);
	endView.setUint16(10, entries.length, true);
	endView.setUint32(12, centralSize, true);
	endView.setUint32(16, offset, true);
	const out = new Uint8Array(offset + centralSize + end.length);
	let cursor = 0;
	for (const part of [
		...locals,
		...centrals,
		end
	]) {
		out.set(part, cursor);
		cursor += part.length;
	}
	return out;
}
function saveBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	document.body.appendChild(link);
	link.click();
	link.remove();
	window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function bytesBlob(data, type) {
	const copy = new Uint8Array(data.byteLength);
	copy.set(data);
	return new Blob([copy], { type });
}
function num(value) {
	if (!value) return NaN;
	const n = Number(value.replace(/[$,%\s,]/g, ""));
	return Number.isFinite(n) ? n : NaN;
}
function money(value) {
	if (!Number.isFinite(value)) return "";
	return value.toLocaleString("en-US", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
}
function dollars(value) {
	const formatted = money(value);
	return formatted ? `$${formatted}` : "";
}
function leaseMath(answers) {
	const rows = [];
	for (let i = 1; i <= 10; i += 1) {
		const rent = num(answers[`row${i}Rent`]);
		const months = num(answers[`row${i}Months`]);
		const pct = num(answers[`row${i}Pct`]);
		const active = [
			answers[`row${i}From`],
			answers[`row${i}To`],
			answers[`row${i}Rent`],
			answers[`row${i}Months`],
			answers[`row${i}Pct`]
		].some((value) => Boolean(value?.trim()));
		const subtotal = rent * months;
		const commission = subtotal * pct / 100;
		rows.push({
			active,
			subtotal: active && Number.isFinite(subtotal) ? subtotal : NaN,
			commission: active && Number.isFinite(subtotal) && Number.isFinite(pct) ? commission : NaN
		});
	}
	return {
		rows,
		consideration: rows.reduce((sum, row) => sum + (Number.isFinite(row.subtotal) ? row.subtotal : 0), 0),
		commission: rows.reduce((sum, row) => sum + (Number.isFinite(row.commission) ? row.commission : 0), 0),
		any: rows.some((row) => row.active)
	};
}
function splitNet(gross, pct) {
	const base = num(gross);
	const rate = num(pct);
	if (!pct?.trim() || !Number.isFinite(base) || !Number.isFinite(rate)) return "";
	return money(base * rate / 100);
}
function splitPercentTotal(answers) {
	let total = 0;
	let any = false;
	for (let i = 1; i <= 4; i += 1) {
		const rate = num(answers[`split${i}Pct`]);
		if (Number.isFinite(rate) && answers[`split${i}Pct`]?.trim()) {
			total += rate;
			any = true;
		}
	}
	return any ? total : NaN;
}
function saleCommission(answers) {
	const base = num(answers.saleBase || answers.price);
	const pct = num(answers.salePct);
	if (!Number.isFinite(base) || !Number.isFinite(pct)) return {
		line: NaN,
		base,
		ready: false
	};
	return {
		line: base * pct / 100,
		base,
		ready: true
	};
}
function pdfText(value) {
	if (!value) return "";
	return value.replace(/[‘’]/g, "'").replace(/[“”]/g, "\"").replace(/[–—]/g, "-").replace(/[^\x0A\x20-\x7E]/g, "").replace(/[ \t]+/g, " ").trim();
}
function wrapLines(value, count, width = 90) {
	const clean = pdfText(value);
	if (!clean) return Array.from({ length: count }, () => "");
	const lines = [];
	for (const piece of clean.split(/\n/)) {
		let rest = piece.trim();
		if (!rest) {
			lines.push("");
			continue;
		}
		while (rest.length > width) {
			let cut = rest.lastIndexOf(" ", width);
			if (cut < 12) cut = width;
			lines.push(rest.slice(0, cut).trim());
			rest = rest.slice(cut).trim();
		}
		lines.push(rest);
	}
	return Array.from({ length: count }, (_, index) => lines[index] ?? "");
}
var TEMPLATES = {
	lease: "/templates/lease.pdf",
	sale: "/templates/sale.pdf",
	consult: "/templates/consult.pdf",
	additional: "/templates/additional.pdf"
};
var PROPERTY = {
	industrial: "Choice1",
	land: "Choice2",
	office: "Choice3",
	retail: "Choice4"
};
function text(form, name, value, max = 80) {
	const clean = pdfText(value).slice(0, max);
	if (!clean) return;
	try {
		const field = form.getTextField(name);
		field.setText(clean);
		try {
			field.setFontSize(8);
		} catch {}
	} catch {}
}
function check(form, name, on) {
	if (!on) return;
	try {
		form.getCheckBox(name).check();
	} catch {}
}
function radio(form, name, option) {
	if (!option) return;
	try {
		form.getRadioGroup(name).select(option);
	} catch {}
}
function office(form, answers) {
	text(form, "S  L", answers.officeSl, 24);
	text(form, "Entered", answers.officeEntered, 24);
	text(form, "Paid", answers.officePaid, 24);
	text(form, "Commerce", answers.officeCommerce, 24);
}
function property(form, answers, group) {
	text(form, "Property Address", answers.address, 70);
	text(form, "City State Zip", answers.city, 70);
	text(form, "Other", answers.propertyOther, 24);
	text(form, "SF", answers.sf, 18);
	radio(form, group, PROPERTY[answers.propertyType ?? ""]);
}
function funds(form, answers, grossName, amountName) {
	check(form, "Check", answers.fundsType === "check");
	check(form, "Wire", answers.fundsType === "wire");
	check(form, "ACH Payment", answers.fundsType === "ach");
	text(form, "Funds Received From", answers.fundsFrom, 40);
	text(form, amountName, answers.amountReceived, 22);
	text(form, grossName, answers.gross, 22);
	text(form, "Outstanding Balance 1", answers.balance, 22);
	text(form, "Outstanding Balance 2", answers.dueDate, 22);
}
function splits(form, answers) {
	[
		[
			"Agent_7",
			"Defer",
			"Entity",
			"of Gross",
			"Net Commission",
			"Runner Name",
			"Runner Commission  Net Check Amount"
		],
		[
			"Agent_8",
			"Defer_2",
			"Entity_2",
			"of Gross_2",
			"Net Commission_2",
			"Runner Name_2",
			"Runner Commission  Net Check Amount_2"
		],
		[
			"Agent_9",
			"Defer_3",
			"Entity_3",
			"of Gross_3",
			"Net Commission_3",
			"Runner Name_3",
			"Runner Commission  Net Check Amount_3"
		],
		[
			"Agent_10",
			"Defer_4",
			"Entity_4",
			"of Gross_4",
			"Net Commission_4",
			"Runner Name_4",
			"Runner Commission  Net Check Amount_4"
		]
	].forEach((names, index) => {
		const n = index + 1;
		text(form, names[0], answers[`split${n}Agent`], 28);
		check(form, names[1], answers[`split${n}Defer`] === "1");
		text(form, names[2], answers[`split${n}Entity`], 28);
		text(form, names[3], answers[`split${n}Pct`], 8);
		text(form, names[4], splitNet(answers.gross, answers[`split${n}Pct`]), 16);
		text(form, names[5], answers[`split${n}Runner`], 28);
		text(form, names[6], answers[`split${n}RunnerAmt`], 16);
	});
}
function external(form, answers, variant) {
	const lease = variant === "lease";
	const left = lease ? [
		"1_3",
		"2_3",
		"City  State  Zip 1",
		"City  State  Zip 2",
		"Text19",
		"Text20",
		"1_5",
		"2_5"
	] : [
		"1",
		"2",
		"City  State  Zip 1",
		"City  State  Zip 2",
		"Area Code 1",
		"Phone Number 1",
		"1_3",
		"2_3"
	];
	const right = lease ? [
		"1_4",
		"2_4",
		"City  State  Zip 1_2",
		"City  State  Zip 2_2",
		"Text21",
		"Text22",
		"1_6",
		"2_6"
	] : [
		"1_2",
		"2_2",
		"City  State  Zip 1_2",
		"City  State  Zip 2_2",
		"Area Code 2",
		"Phone Number 2",
		"1_4",
		"2_4"
	];
	writeExternal(form, answers, 1, left, "Licensed", "Unlicensed", "Salesperson DRE", "Commission Amount");
	writeExternal(form, answers, 2, right, "Licensed_2", "Unlicensed_2", "Salesperson DRE_2", "Commission Amount_2");
}
function writeExternal(form, answers, n, names, licensed, unlicensed, salesperson, commission) {
	const [company, address, city, contact, area, phone, email, corp] = names;
	text(form, company, answers[`ext${n}Company`], 36);
	text(form, address, answers[`ext${n}Address`], 36);
	text(form, city, answers[`ext${n}City`], 36);
	text(form, contact, answers[`ext${n}Contact`], 36);
	text(form, area, answers[`ext${n}Area`], 3);
	text(form, phone, answers[`ext${n}Phone`], 16);
	text(form, email, answers[`ext${n}Email`], 36);
	text(form, corp, answers[`ext${n}Corp`], 20);
	text(form, salesperson, answers[`ext${n}Sales`], 20);
	text(form, commission, answers[`ext${n}Commission`], 18);
	check(form, licensed, answers[`ext${n}License`] === "licensed");
	check(form, unlicensed, answers[`ext${n}License`] === "unlicensed");
}
function marketing(form, answers, highlightLines) {
	check(form, "Gift Basket", answers.mktGift === "1");
	check(form, "Press Release", answers.mktPress === "1");
	check(form, "Add to Website  Online Resume", answers.mktWeb === "1");
	check(form, "Remove Sign", answers.mktSign === "1");
	check(form, "Postcard", answers.mktCard === "1");
	text(form, "Criteria", answers.mktCriteria, 40);
	check(form, "Add to LeePro Transaction Summary Report", answers.mktLeepro === "1");
	text(form, "Reference Contact", answers.mktRef, 36);
	const lines = wrapLines(answers.highlights, highlightLines, 80);
	if (highlightLines === 1) text(form, "Highlights", lines[0], 80);
	else lines.forEach((line, index) => text(form, `Highlights ${index + 1}`, line, 80));
}
function invoiceYesNo(form, answers) {
	check(form, "Invoice", answers.invoice === "yes");
	check(form, "Yes", answers.invoice === "no");
}
function billTo(form, answers) {
	text(form, "Name", answers.billName, 36);
	text(form, "Company", answers.billCompany, 36);
	text(form, "City State Zip_2", answers.billCity, 70);
}
function listingAgents(form, answers) {
	[
		[
			"Agent",
			"Firm",
			"Agent_2",
			"Firm_2"
		],
		[
			"Agent_3",
			"Firm_3",
			"Agent_4",
			"Firm_4"
		],
		[
			"Agent_5",
			"Firm_5",
			"Agent_6",
			"Firm_6"
		]
	].forEach((names, index) => {
		const n = index + 1;
		text(form, names[0], answers[`list${n}Name`], 32);
		text(form, names[1], answers[`list${n}Firm`], 32);
		text(form, names[2], answers[`proc${n}Name`], 32);
		text(form, names[3], answers[`proc${n}Firm`], 32);
	});
}
function fillLease(form, answers) {
	office(form, answers);
	check(form, "Lease", answers.transaction === "lease");
	check(form, "Sublease", answers.transaction === "sublease");
	check(form, "Lease Renewal", answers.transaction === "renewal");
	property(form, answers, "Group23");
	[
		"Executed lease",
		"Property information sheet",
		"Lee & Associates disclosure",
		"Agency disclosure",
		"Listing agreement",
		"Offer / counter offer",
		"Finder's fee agreement"
	].forEach((_, index) => check(form, `Check Box${index + 1}`, answers[`checkLease${index + 1}`] === "1"));
	const subDocs = 9;
	for (let i = 1; i <= subDocs; i += 1) check(form, `Check Box${i + 7}`, answers[`checkSub${i}`] === "1");
	check(form, "Check Box17", answers.checkRen1 === "1");
	check(form, "Check Box18", answers.checkRen2 === "1");
	text(form, "9", answers.lessor, 36);
	text(form, "1", answers.lessee, 36);
	text(form, "Company DBA 1", answers.lessorDba, 36);
	text(form, "2", answers.lesseeDba, 36);
	text(form, "Company DBA 2", answers.lessorContact, 36);
	text(form, "3", answers.lesseeContact, 36);
	check(form, "Lessor", answers.represented === "lessor");
	check(form, "Lessee", answers.represented === "lessee");
	check(form, "Both", answers.represented === "both");
	text(form, "undefined", answers.leaseFrom, 16);
	text(form, "through", answers.leaseThrough, 16);
	text(form, "Lease Execution Date", answers.executionDate, 20);
	text(form, "Term Mos", answers.leasedSf, 16);
	text(form, "Total Building SF", answers.buildingSf, 16);
	text(form, "TI Allowance", answers.landSf, 16);
	text(form, "undefined_2", answers.officeSf, 16);
	text(form, "Lease Option Terms", answers.leaseOption, 28);
	text(form, "Exercise Time Frame", answers.exerciseLeft, 28);
	text(form, "1_2", answers.askingRate, 16);
	text(form, "Rate Type", answers.askingType, 12);
	text(form, "2_2", answers.leaseRate, 16);
	text(form, "Rate Type_2", answers.leaseType, 12);
	text(form, "3_2", answers.effectiveRate, 16);
	text(form, "Rate Type_3", answers.effectiveType, 12);
	text(form, "4", answers.termMos, 8);
	text(form, "Total Consideration 1", answers.considerationNote, 22);
	text(form, "Total Consideration 2", answers.ti, 22);
	text(form, "Purchase Option Terms", answers.purchaseOption, 28);
	text(form, "Exercise Time Frame 1", answers.exerciseRight, 22);
	text(form, "Exercise Time Frame 2", answers.freeRent, 22);
	for (let i = 1; i <= 5; i += 1) {
		text(form, `Period ${i}`, answers[`esc${i}Period`], 16);
		text(form, `Rate PSF ${i}`, answers[`esc${i}Psf`], 12);
		text(form, `Rate Type ${i}`, answers[`esc${i}Type`], 12);
	}
	wrapLines(answers.escNotes, 4, 40).forEach((line, index) => text(form, `Comments ${index + 1}`, line, 40));
	text(form, "NNN  CAM Charges", answers.nnn, 50);
	listingAgents(form, answers);
	funds(form, answers, "Amount Received 2", "Amount Received 1");
	invoiceYesNo(form, answers);
	splits(form, answers);
	external(form, answers, "lease");
	marketing(form, answers, 4);
	billTo(form, answers);
	const math = leaseMath(answers);
	for (let i = 0; i < 10; i += 1) {
		const n = i + 1;
		const suffix = n === 1 ? "" : `_${n}`;
		text(form, `Mos${suffix}`, answers[`row${n}From`], 4);
		text(form, `to${suffix}`, answers[`row${n}To`], 4);
		text(form, `undefined_${3 + i * 2}`, answers[`row${n}Rent`], 12);
		text(form, `Month x${suffix}`, answers[`row${n}Months`], 4);
		text(form, n === 1 ? "x" : `x_${n}`, answers[`row${n}Pct`], 6);
		const row = math.rows[i];
		if (row?.active && Number.isFinite(row.subtotal)) text(form, `Months${suffix}`, money(row.subtotal), 14);
		if (row?.active && Number.isFinite(row.commission)) text(form, `undefined_${4 + i * 2}`, money(row.commission), 14);
	}
	if (math.any) {
		text(form, "Total Consideration", money(math.consideration), 16);
		text(form, "Total Commission", money(math.commission), 16);
	}
	const commentLines = [
		"Comments",
		"1_7",
		"2_7"
	];
	wrapLines(answers.comments, 3, 100).forEach((line, index) => {
		text(form, commentLines[index] ?? "Comments", line, 110);
	});
	text(form, "undefined_23", answers.agentSign, 36);
	text(form, "undefined_24", answers.brokerSign, 36);
}
function fillSale(form, answers) {
	office(form, answers);
	property(form, answers, "Group1");
	for (let i = 2; i <= 15; i += 1) check(form, `Check Box${i}`, answers[`checkSale${i}`] === "1");
	text(form, "Asking Price", answers.asking, 22);
	text(form, "Close of Escrow Date", answers.closeDate, 20);
	text(form, "Purchase Price", answers.price, 22);
	wrapLines(answers.saleNotes, 2, 70).forEach((line, index) => text(form, `Comments ${index + 1}`, line, 70));
	text(form, "undefined", answers.seller, 36);
	text(form, "undefined_2", answers.buyer, 36);
	text(form, "Company DBA 1", answers.sellerDba, 36);
	text(form, "Company DBA 1_2", answers.buyerDba, 36);
	text(form, "Company DBA 2", answers.sellerContact, 36);
	text(form, "Company DBA 2_2", answers.buyerContact, 36);
	check(form, "User", answers.buyerType === "user");
	check(form, "Investor", answers.buyerType === "investor");
	listingAgents(form, answers);
	funds(form, answers, "Amount Received 2", "Amount Received 1");
	invoiceYesNo(form, answers);
	splits(form, answers);
	external(form, answers, "sale");
	marketing(form, answers, 1);
	billTo(form, answers);
	const commission = saleCommission(answers);
	text(form, "undefined_3", answers.saleBase || answers.price, 16);
	text(form, "x", answers.salePct, 8);
	if (commission.ready) text(form, "undefined_4", money(commission.line), 16);
	const totalConsideration = answers.totalConsideration || (commission.ready ? money(commission.base) : answers.price);
	const totalCommission = answers.totalCommission || (commission.ready ? money(commission.line) : "");
	text(form, "Total Consideration", totalConsideration, 16);
	text(form, "Total Commission", totalCommission, 16);
	text(form, "Comments", pdfText(answers.comments).slice(0, 90), 90);
	text(form, "undefined_5", answers.agentSign, 36);
	text(form, "undefined_6", answers.brokerSign, 36);
}
function fillConsult(form, answers) {
	office(form, answers);
	check(form, "Referral", answers.engagement === "referral");
	check(form, "Consulting", answers.engagement === "consulting");
	property(form, answers, "Group1");
	check(form, "Check Box2", answers.checkCon1 === "1");
	check(form, "Check Box3", answers.checkCon2 === "1");
	check(form, "Check Box4", answers.checkRef1 === "1");
	check(form, "Check Box5", answers.checkRef2 === "1");
	check(form, "Check Box6", answers.checkRef3 === "1");
	funds(form, answers, "Commission Distribution  INTERNAL", "Amount Received");
	splits(form, answers);
	external(form, answers, "sale");
	text(form, "Comments", pdfText(answers.sideComment).slice(0, 80), 80);
	radio(form, "If Yes See Below", answers.invoice === "yes" ? "Yes" : answers.invoice === "no" ? "No" : void 0);
	billTo(form, answers);
	wrapLines(answers.comments, 5, 100).forEach((line, index) => {
		text(form, [
			"Comments_2",
			"1_5",
			"2_5",
			"3",
			"4"
		][index] ?? "Comments_2", line, 110);
	});
	text(form, "undefined", answers.agentSign, 36);
	text(form, "undefined_2", answers.brokerSign, 36);
}
function draw(page, font, value, x, y, max = 42) {
	const clean = pdfText(value).slice(0, max);
	if (!clean) return;
	page.drawText(clean, {
		x,
		y,
		size: 9,
		font,
		color: rgb(.11, .14, .19)
	});
}
function mark(page, font, x, y) {
	page.drawText("X", {
		x,
		y,
		size: 10,
		font,
		color: rgb(.77, .07, .19)
	});
}
function fillAdditional(page, font, answers) {
	draw(page, font, answers.officeSl, 478, 951, 16);
	draw(page, font, answers.officeEntered, 478, 935, 16);
	draw(page, font, answers.officePaid, 478, 919, 16);
	draw(page, font, answers.officeCommerce, 478, 904, 16);
	draw(page, font, answers.address, 128, 928, 48);
	draw(page, font, answers.city, 118, 902, 55);
	draw(page, font, answers.seller, 118, 871, 28);
	draw(page, font, answers.buyer, 400, 871, 28);
	draw(page, font, answers.sellerDba, 112, 849, 28);
	draw(page, font, answers.buyerDba, 392, 849, 28);
	draw(page, font, answers.sellerContact, 88, 827, 28);
	draw(page, font, answers.buyerContact, 368, 827, 28);
	if (answers.fundsType === "check") mark(page, font, 124, 779);
	if (answers.fundsType === "wire") mark(page, font, 186, 779);
	if (answers.fundsType === "ach") mark(page, font, 234, 779);
	draw(page, font, answers.balance, 460, 781, 16);
	draw(page, font, answers.fundsFrom, 150, 758, 28);
	draw(page, font, answers.dueDate, 410, 758, 16);
	draw(page, font, answers.amountReceived, 130, 736, 20);
	draw(page, font, answers.gross, 112, 714, 20);
	[
		{
			yAgent: 672,
			yEntity: 650,
			yPct: 627,
			yRunner: 591,
			yAmt: 569,
			x: 72,
			xDefer: 268,
			xNet: 230
		},
		{
			yAgent: 672,
			yEntity: 650,
			yPct: 627,
			yRunner: 591,
			yAmt: 569,
			x: 365,
			xDefer: 538,
			xNet: 510
		},
		{
			yAgent: 537,
			yEntity: 515,
			yPct: 493,
			yRunner: 456,
			yAmt: 434,
			x: 72,
			xDefer: 268,
			xNet: 230
		},
		{
			yAgent: 537,
			yEntity: 515,
			yPct: 493,
			yRunner: 456,
			yAmt: 434,
			x: 365,
			xDefer: 538,
			xNet: 510
		}
	].forEach((slot, index) => {
		const n = index + 1;
		draw(page, font, answers[`split${n}Agent`], slot.x, slot.yAgent, 22);
		if (answers[`split${n}Defer`] === "1") mark(page, font, slot.xDefer, slot.yAgent - 2);
		draw(page, font, answers[`split${n}Entity`], slot.x, slot.yEntity, 22);
		draw(page, font, answers[`split${n}Pct`], slot.x + 28, slot.yPct, 6);
		draw(page, font, splitNet(answers.gross, answers[`split${n}Pct`]), slot.xNet, slot.yPct, 12);
		draw(page, font, answers[`split${n}Runner`], slot.x + 40, slot.yRunner, 22);
		draw(page, font, answers[`split${n}RunnerAmt`], slot.x + 180, slot.yAmt, 12);
	});
	[{
		x: 90,
		markLic: 128,
		markUn: 198
	}, {
		x: 390,
		markLic: 426,
		markUn: 496
	}].forEach((column, index) => {
		const n = index + 1;
		if (answers[`ext${n}License`] === "licensed") mark(page, font, column.markLic, 377);
		if (answers[`ext${n}License`] === "unlicensed") mark(page, font, column.markUn, 377);
		draw(page, font, answers[`ext${n}Company`], column.x, 352, 28);
		draw(page, font, answers[`ext${n}Address`], column.x, 332, 28);
		draw(page, font, answers[`ext${n}City`], column.x + 30, 312, 24);
		draw(page, font, answers[`ext${n}Contact`], column.x, 292, 28);
		draw(page, font, answers[`ext${n}Area`], column.x + 55, 272, 3);
		draw(page, font, answers[`ext${n}Phone`], column.x + 82, 272, 14);
		draw(page, font, answers[`ext${n}Email`], column.x - 10, 252, 28);
		draw(page, font, answers[`ext${n}Corp`], column.x + 10, 232, 16);
		draw(page, font, answers[`ext${n}Sales`], column.x + 40, 212, 16);
		draw(page, font, answers[`ext${n}Commission`], column.x + 50, 192, 14);
	});
	wrapLines(answers.comments, 2, 70).forEach((line, index) => draw(page, font, line, 95, 171 - index * 16, 70));
	draw(page, font, answers.agentSign, 68, 64, 32);
	draw(page, font, answers.brokerSign, 331, 64, 32);
}
async function buildVoucher(bytes, packet) {
	const doc = await PDFDocument.load(bytes);
	if (packet.kind === "additional") {
		const font = await doc.embedFont(StandardFonts.Helvetica);
		const page = doc.getPages()[0];
		if (!page) throw new Error("Additional payment template has no pages.");
		fillAdditional(page, font, packet.answers);
	} else {
		const form = doc.getForm();
		const font = await doc.embedFont(StandardFonts.Helvetica);
		if (packet.kind === "lease") fillLease(form, packet.answers);
		if (packet.kind === "sale") fillSale(form, packet.answers);
		if (packet.kind === "consult") fillConsult(form, packet.answers);
		try {
			form.updateFieldAppearances(font);
			form.flatten();
		} catch {}
	}
	return doc.save();
}
function voucherFilename(packet) {
	const address = (packet.answers.address || KIND_META[packet.kind].short).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40);
	const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	return `${packet.kind}-${address || "voucher"}-${day}.pdf`;
}
async function renderVoucher(packet) {
	const response = await fetch(TEMPLATES[packet.kind]);
	if (!response.ok) throw new Error("Template unavailable");
	return buildVoucher(await response.arrayBuffer(), packet);
}
async function downloadVoucher(packet) {
	saveBlob(bytesBlob(await renderVoucher(packet), "application/pdf"), voucherFilename(packet));
}
var DB_NAME = "lee-deal-files";
var STORE = "blobs";
function openDb() {
	return new Promise((resolve, reject) => {
		const request = indexedDB.open(DB_NAME, 1);
		request.onupgradeneeded = () => {
			const db = request.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" }).createIndex("packetId", "packetId");
		};
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("Could not open file storage."));
	});
}
function finish(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("File storage failed."));
		tx.onabort = () => reject(tx.error ?? /* @__PURE__ */ new Error("File storage was aborted."));
	});
}
async function putBlob(packetId, id, blob) {
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put({
			id,
			packetId,
			blob
		});
		await finish(tx);
	} finally {
		db.close();
	}
}
async function getBlob(id) {
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readonly");
		const row = await new Promise((resolve, reject) => {
			const request = tx.objectStore(STORE).get(id);
			request.onsuccess = () => resolve(request.result);
			request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("Could not read the file."));
		});
		await finish(tx);
		return row?.blob ?? null;
	} finally {
		db.close();
	}
}
async function deleteBlob(id) {
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(id);
		await finish(tx);
	} finally {
		db.close();
	}
}
async function deletePacketBlobs(packetId) {
	if (typeof indexedDB === "undefined") return;
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readwrite");
		const request = tx.objectStore(STORE).index("packetId").openCursor(IDBKeyRange.only(packetId));
		request.onsuccess = () => {
			const cursor = request.result;
			if (!cursor) return;
			cursor.delete();
			cursor.continue();
		};
		await finish(tx);
	} finally {
		db.close();
	}
}
function line(label, value) {
	const text = value?.trim();
	return text ? `${label}: ${text}` : null;
}
function block(title, rows) {
	const kept = rows.filter((row) => Boolean(row));
	if (kept.length === 0) return [];
	return [
		"",
		title,
		...kept
	];
}
function voucherLetter(packet, fileNames) {
	const answers = packet.answers;
	const kind = KIND_META[packet.kind].title;
	const splits = [];
	for (let i = 1; i <= 8; i += 1) {
		const agent = answers[`split${i}Agent`]?.trim();
		if (!agent) continue;
		const pct = answers[`split${i}Pct`]?.trim();
		const entity = answers[`split${i}Entity`]?.trim();
		splits.push([
			agent,
			pct ? `${pct}%` : "",
			entity
		].filter(Boolean).join(" · "));
	}
	const outside = [];
	for (let i = 1; i <= 4; i += 1) {
		const firm = answers[`out${i}Firm`]?.trim();
		if (!firm) continue;
		const pct = answers[`out${i}Pct`]?.trim();
		outside.push([
			firm,
			pct ? `${pct}%` : "",
			answers[`out${i}Agent`]?.trim()
		].filter(Boolean).join(" · "));
	}
	const files = packetFiles(packet).map((file) => `${slotLabel(packet.kind, file.slot)} — ${file.name}`);
	return [
		`Lee & Associates ${kind}`,
		packetTitle(packet),
		answers.city?.trim() ?? "",
		"",
		"This voucher was sent from Deal Desk. The filled office form is attached as a PDF. Backup documents are attached separately — there is no zip file.",
		...block("Property", [
			line("Address", answers.address),
			line("City", answers.city),
			line("Type", answers.propertyType),
			line("Other type", answers.propertyOther),
			line("Square feet", answers.sf),
			line("Transaction", answers.transaction),
			line("Engagement", answers.engagement)
		]),
		...block("Parties", [
			line("Lessor", answers.lessor),
			line("Lessor DBA", answers.lessorDba),
			line("Lessor contact", answers.lessorContact),
			line("Lessee", answers.lessee),
			line("Lessee contact", answers.lesseeContact),
			line("Seller", answers.seller),
			line("Buyer", answers.buyer),
			line("Client", answers.client),
			line("Represented", answers.represented)
		]),
		...block("Terms", [
			line("Lease from", answers.leaseFrom),
			line("Lease through", answers.leaseThrough),
			line("Execution date", answers.executionDate),
			line("Leased square feet", answers.leasedSf),
			line("Term (months)", answers.termMos),
			line("Asking rate", answers.askingRate),
			line("Lease rate", answers.leaseRate),
			line("Effective rate", answers.effectiveRate),
			line("TI", answers.ti),
			line("Free rent", answers.freeRent),
			line("Purchase price", answers.price),
			line("Close date", answers.closeDate),
			line("Escrow", answers.escrow),
			line("Fee", answers.fee)
		]),
		...block("Money", [
			line("Funds", answers.fundsType),
			line("Received from", answers.fundsFrom),
			line("Amount received", answers.amountReceived),
			line("Gross commission", answers.gross),
			line("Commission %", answers.salePct),
			...splits.map((row) => `Inside split: ${row}`),
			...outside.map((row) => `Outside firm: ${row}`)
		]),
		...block("Invoice", [
			line("Bill to", answers.billName),
			line("Company", answers.billCompany),
			line("City", answers.billCity),
			line("Send invoice", answers.invoice)
		]),
		...block("Agent", [line("Signed", answers.agentSign)]),
		"",
		"Attached",
		...fileNames.map((name) => `- ${name}`),
		...files.length ? [
			"",
			"Backup on the voucher",
			...files.map((name) => `- ${name}`)
		] : [],
		""
	].filter((row) => row !== void 0).join("\n");
}
var sendVoucherEmail = createServerFn({ method: "POST" }).validator((data) => data).middleware([authMiddleware]).handler(createSsrRpc("3d4f3b900840631ecdc0cc66258108bd2bd34781c314194210a05b1b2e13dd0c"));
var ACCEPT = ".pdf,.png,.jpg,.jpeg,.webp,.gif,.doc,.docx,.xls,.xlsx,.csv,.txt,.tif,.tiff";
var EXT = /\.(pdf|png|jpe?g|webp|gif|docx?|xlsx?|csv|txt|tiff?)$/i;
var ALLOWED = /* @__PURE__ */ new Set([
	"application/pdf",
	"image/png",
	"image/jpeg",
	"image/webp",
	"image/gif",
	"image/tiff",
	"text/plain",
	"text/csv",
	"application/msword",
	"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	"application/vnd.ms-excel",
	"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
]);
function formatBytes(size) {
	if (size < 1024) return `${size} B`;
	if (size < 1048576) return `${Math.max(1, Math.round(size / 1024))} KB`;
	const mb = size / 1048576;
	return `${mb >= 10 ? Math.round(mb) : Math.round(mb * 10) / 10} MB`;
}
function safeFileName(name) {
	return ((name.split(/[/\\]/).pop() ?? "file").replace(/[^A-Za-z0-9._-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "") || "file").slice(0, 80);
}
function allowed(file) {
	return ALLOWED.has(file.type) || EXT.test(file.name);
}
function intakeError(file, count, bytes) {
	if (count >= 24) return `A packet holds up to 24 files.`;
	if (file.size <= 0) return `${file.name} is empty.`;
	if (file.size > 12582912) return `${file.name} is over 12 MB.`;
	if (bytes + file.size > 50331648) return "This packet is at the 48 MB file limit.";
	if (!allowed(file)) return `${file.name} needs to be a PDF, image, Word, Excel, or text file.`;
	return null;
}
async function storeIncoming(packetId, slot, list, existing) {
	const added = [];
	const errors = [];
	let count = existing.length;
	let bytes = existing.reduce((sum, file) => sum + file.size, 0);
	for (const file of Array.from(list)) {
		const problem = intakeError(file, count, bytes);
		if (problem) {
			errors.push(problem);
			continue;
		}
		const id = crypto.randomUUID();
		try {
			await putBlob(packetId, id, file);
		} catch (error) {
			const quota = error instanceof DOMException && error.name === "QuotaExceededError";
			errors.push(quota ? "This browser is out of room for more deal files." : `${file.name} could not be saved.`);
			continue;
		}
		added.push({
			id,
			slot,
			name: file.name,
			type: file.type || "application/octet-stream",
			size: file.size,
			addedAt: Date.now()
		});
		count += 1;
		bytes += file.size;
	}
	return {
		added,
		errors
	};
}
function uniquePath(used, name) {
	if (!used.has(name)) {
		used.add(name);
		return name;
	}
	const slash = name.lastIndexOf("/");
	const dir = slash >= 0 ? name.slice(0, slash + 1) : "";
	const file = slash >= 0 ? name.slice(slash + 1) : name;
	const dot = file.lastIndexOf(".");
	const stem = dot > 0 ? file.slice(0, dot) : file;
	const ext = dot > 0 ? file.slice(dot) : "";
	let next = name;
	let n = 2;
	while (used.has(next)) {
		next = `${dir}${stem}-${n}${ext}`;
		n += 1;
	}
	used.add(next);
	return next;
}
function packetZipName(packet) {
	return voucherFilename(packet).replace(/\.pdf$/, "-packet.zip");
}
function mailSubject(packet) {
	return `${KIND_META[packet.kind].title} — ${packetTitle(packet)}`;
}
function bytesToBase64(bytes) {
	const chunk = 32768;
	let binary = "";
	for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunk, bytes.length)));
	return btoa(binary);
}
async function emailPacket(packet, to) {
	const pdf = await renderVoucher(packet);
	const pdfName = voucherFilename(packet);
	const attachments = [{
		filename: pdfName,
		mimeType: "application/pdf",
		contentBase64: bytesToBase64(pdf)
	}];
	const names = [pdfName];
	let missing = 0;
	for (const file of packetFiles(packet)) {
		const blob = await getBlob(file.id);
		if (!blob) {
			missing += 1;
			continue;
		}
		const bytes = new Uint8Array(await blob.arrayBuffer());
		attachments.push({
			filename: file.name,
			mimeType: file.type || "application/octet-stream",
			contentBase64: bytesToBase64(bytes)
		});
		names.push(file.name);
	}
	const result = await sendVoucherEmail({ data: {
		to,
		subject: mailSubject(packet),
		body: voucherLetter(packet, names),
		attachments
	} });
	if (!result.ok) {
		const error = new Error(result.errorMessage || "The voucher could not be sent.");
		Object.assign(error, result);
		throw error;
	}
	return { missing };
}
async function buildPacket(packet) {
	const pdf = await renderVoucher(packet);
	const pdfName = voucherFilename(packet);
	const filename = packetZipName(packet);
	const used = /* @__PURE__ */ new Set([pdfName, "readme.txt"]);
	const entries = [{
		name: pdfName,
		data: pdf
	}];
	const included = [pdfName];
	const missing = [];
	for (const file of packetFiles(packet)) {
		const blob = await getBlob(file.id);
		const label = slotLabel(packet.kind, file.slot);
		if (!blob) {
			missing.push(`${label} (${file.name})`);
			continue;
		}
		const path = uniquePath(used, `files/${safeFileName(label)}--${safeFileName(file.name)}`);
		entries.push({
			name: path,
			data: new Uint8Array(await blob.arrayBuffer())
		});
		included.push(path);
	}
	const readme = [
		"Lee & Associates deal packet",
		KIND_META[packet.kind].title,
		packetTitle(packet),
		packet.answers.city?.trim() ?? "",
		packet.status === "submitted" ? "Status: Submitted" : "Status: Draft",
		"",
		"Included",
		...included.map((name) => `- ${name}`),
		...missing.length ? [
			"",
			"Not in this browser",
			...missing.map((name) => `- ${name}`)
		] : [],
		""
	].join("\n");
	entries.push({
		name: "readme.txt",
		data: new TextEncoder().encode(readme)
	});
	return {
		blob: bytesBlob(zipStore(entries), "application/zip"),
		filename,
		missing: missing.length
	};
}
async function downloadPacket(packet) {
	const built = await buildPacket(packet);
	saveBlob(built.blob, built.filename);
	return built.missing;
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var KINDS = /* @__PURE__ */ new Set([
	"lease",
	"sale",
	"consult",
	"additional"
]);
var STATUSES = /* @__PURE__ */ new Set(["draft", "submitted"]);
function cleanAnswers(raw) {
	const answers = {};
	if (!raw || typeof raw !== "object") return answers;
	for (const [key, value] of Object.entries(raw)) {
		if (key.length > 40 || typeof value !== "string" || value.length > 4e3 || !value) continue;
		answers[key] = value;
		if (Object.keys(answers).length >= 400) break;
	}
	return answers;
}
function cleanFiles(raw) {
	if (!Array.isArray(raw)) return [];
	const files = [];
	for (const file of raw) {
		if (!file || typeof file.id !== "string" || typeof file.name !== "string") continue;
		files.push({
			id: file.id.slice(0, 80),
			slot: String(file.slot ?? "other").slice(0, 40),
			name: file.name.slice(0, 180),
			type: String(file.type ?? "application/octet-stream").slice(0, 120),
			size: Number.isFinite(file.size) ? Math.max(0, Math.round(file.size)) : 0,
			addedAt: Number.isFinite(file.addedAt) ? file.addedAt : Date.now()
		});
		if (files.length >= 40) break;
	}
	return files;
}
function cleanPacket(input) {
	if (!input || typeof input.id !== "string" || !/^[0-9a-f-]{16,80}$/i.test(input.id)) throw new Error("That voucher cannot be saved.");
	if (!KINDS.has(input.kind) || !STATUSES.has(input.status)) throw new Error("That voucher cannot be saved.");
	return {
		id: input.id,
		kind: input.kind,
		status: input.status,
		createdAt: Number.isFinite(input.createdAt) ? input.createdAt : Date.now(),
		updatedAt: Number.isFinite(input.updatedAt) ? input.updatedAt : Date.now(),
		submittedAt: input.submittedAt,
		answers: cleanAnswers(input.answers),
		files: cleanFiles(input.files)
	};
}
var listDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("e74c30d9e05d59f1eee8ed99d33b1d114f98aa2482e91f12576ff50e086f56aa"));
var saveDeskPacket = createServerFn({ method: "POST" }).validator((input) => cleanPacket(input)).middleware([authMiddleware]).handler(createSsrRpc("3cf09d261462c953760c432eebba6703ebf63ab69215d3704fb608bfdd29ec38"));
var deleteDeskPacket = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(createSsrRpc("8be4a52330d87e9641de94e5d5d8db6b0fddca84b2aa6350eeb5d3501d0230d9"));
var saveDeskEmail = createServerFn({ method: "POST" }).validator((email) => email.trim().slice(0, 180)).middleware([authMiddleware]).handler(createSsrRpc("96fdfecdc33eb7b4199998b920dbf9847f5d4958d59da3058dcfa0bb54de6fa6"));
var saveDeskFile = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("518df06f523d0a52b0c8d8d2ae1a557bba3bd37ddfe21c82d13130692d16f5b7"));
var deleteDeskFile = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(createSsrRpc("eee19710a95440130c4c249fd1bcab6c334b364702e9734fb4e3a9c76e9b091c"));
var fetchDeskFile = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(createSsrRpc("50efc53b1d699657dd5a251ebcb5af2ad5d2a59d8338713549b17a627baa78c1"));
var SAMPLE = {
	sample: "1",
	transaction: "lease",
	address: "1400 E Walnut Ave",
	city: "Commerce, CA 90040",
	propertyType: "industrial",
	sf: "42,500",
	lessor: "Walnut Industrial Holdings LLC",
	lessorDba: "Walnut Industrial",
	lessorContact: "Elena Cho",
	lessee: "Pacific Cold Storage Inc.",
	lesseeContact: "Marcus Hale",
	represented: "both",
	leaseFrom: "11/01/2026",
	leaseThrough: "10/31/2031",
	executionDate: "10/06/2026",
	leasedSf: "42,500",
	buildingSf: "86,000",
	askingRate: "1.35",
	askingType: "NNN",
	leaseRate: "1.28",
	leaseType: "NNN",
	effectiveRate: "1.22",
	effectiveType: "NNN",
	termMos: "60",
	ti: "15.00 PSF",
	freeRent: "2 months",
	nnn: "NNN, estimated $0.28 PSF",
	esc1Period: "Year 1",
	esc1Psf: "1.28",
	esc1Type: "NNN",
	esc2Period: "Years 2-5",
	esc2Psf: "3% annual",
	esc2Type: "NNN",
	row1From: "1",
	row1To: "60",
	row1Rent: "54400",
	row1Months: "60",
	row1Pct: "6",
	fundsType: "wire",
	fundsFrom: "Pacific Cold Storage Inc.",
	amountReceived: "195,840.00",
	gross: "195,840.00",
	split1Agent: "A. Reyes",
	split1Entity: "Lee & Associates",
	split1Pct: "60",
	split2Agent: "J. Patel",
	split2Entity: "Lee & Associates",
	split2Pct: "40",
	list1Name: "A. Reyes",
	list1Firm: "Lee & Associates",
	proc1Name: "J. Patel",
	proc1Firm: "Lee & Associates",
	checkLease1: "1",
	checkLease2: "1",
	checkLease5: "1",
	billName: "Accounts Payable",
	billCompany: "Pacific Cold Storage Inc.",
	billCity: "Commerce, CA 90040",
	invoice: "no",
	agentSign: "A. Reyes"
};
function remember(error) {
	const message = error instanceof Error ? error.message : "Could not save to your account.";
	useDesk.setState({ saveError: message });
}
function saved() {
	if (useDesk.getState().saveError) useDesk.setState({ saveError: "" });
}
var packetTimers = /* @__PURE__ */ new Map();
function queuePacket(id) {
	const existing = packetTimers.get(id);
	if (existing) clearTimeout(existing);
	packetTimers.set(id, setTimeout(() => {
		packetTimers.delete(id);
		const packet = useDesk.getState().packets.find((item) => item.id === id);
		if (!packet) return;
		saveDeskPacket({ data: packet }).then(saved).catch(remember);
	}, 400));
}
var emailTimer;
function queueEmail(email) {
	if (emailTimer) clearTimeout(emailTimer);
	emailTimer = setTimeout(() => {
		saveDeskEmail({ data: email }).then(saved).catch(remember);
	}, 400);
}
function blobToBase64(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			const result = String(reader.result ?? "");
			const comma = result.indexOf(",");
			resolve(comma >= 0 ? result.slice(comma + 1) : result);
		};
		reader.onerror = () => reject(reader.error ?? /* @__PURE__ */ new Error("Could not read the file."));
		reader.readAsDataURL(blob);
	});
}
async function uploadFile(packetId, file) {
	const blob = await getBlob(file.id);
	if (!blob) return;
	await saveDeskFile({ data: {
		packetId,
		id: file.id,
		name: file.name,
		mime: file.type,
		slot: file.slot,
		contentBase64: await blobToBase64(blob)
	} });
}
var useDesk = create()((set, get) => ({
	packets: [],
	defaultEmail: "",
	saveError: "",
	createPacket: (kind, answers = {}) => {
		const id = crypto.randomUUID();
		const now = Date.now();
		const packet = {
			id,
			kind,
			status: "draft",
			createdAt: now,
			updatedAt: now,
			answers,
			files: []
		};
		set((state) => ({ packets: [packet, ...state.packets] }));
		saveDeskPacket({ data: packet }).then(saved).catch(remember);
		return id;
	},
	updateAnswer: (id, key, value) => {
		set((state) => ({ packets: state.packets.map((packet) => {
			if (packet.id !== id) return packet;
			const answers = { ...packet.answers };
			if (value) answers[key] = value;
			else delete answers[key];
			return {
				...packet,
				answers,
				updatedAt: Date.now()
			};
		}) }));
		queuePacket(id);
	},
	addFiles: (id, incoming) => {
		if (incoming.length === 0) return;
		set((state) => ({ packets: state.packets.map((packet) => packet.id === id ? {
			...packet,
			files: [...packet.files ?? [], ...incoming],
			updatedAt: Date.now()
		} : packet) }));
		const packet = get().packets.find((item) => item.id === id);
		(async () => {
			if (packet) await saveDeskPacket({ data: packet });
			for (const file of incoming) await uploadFile(id, file);
			saved();
		})().catch(remember);
	},
	removeFile: (id, fileId) => {
		set((state) => ({ packets: state.packets.map((packet) => packet.id === id ? {
			...packet,
			files: (packet.files ?? []).filter((file) => file.id !== fileId),
			updatedAt: Date.now()
		} : packet) }));
		const packet = get().packets.find((item) => item.id === id);
		(async () => {
			if (packet) await saveDeskPacket({ data: packet });
			await deleteDeskFile({ data: fileId });
			saved();
		})().catch(remember);
	},
	setStatus: (id, status) => {
		set((state) => ({ packets: state.packets.map((packet) => packet.id === id ? {
			...packet,
			status,
			updatedAt: Date.now(),
			submittedAt: status === "submitted" ? Date.now() : packet.submittedAt
		} : packet) }));
		const packet = get().packets.find((item) => item.id === id);
		if (packet) saveDeskPacket({ data: packet }).then(saved).catch(remember);
	},
	setDefaultEmail: (email) => {
		set({ defaultEmail: email });
		queueEmail(email);
	},
	removePacket: (id) => {
		set((state) => ({ packets: state.packets.filter((packet) => packet.id !== id) }));
		deletePacketBlobs(id);
		deleteDeskPacket({ data: id }).then(saved).catch(remember);
	}
}));
function sampleAnswers() {
	return { ...SAMPLE };
}
var loadedFor = "";
var loadPromise = null;
function readBrowserDrafts() {
	if (typeof localStorage === "undefined") return null;
	try {
		const raw = localStorage.getItem("lee-deal-desk");
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		return {
			packets: Array.isArray(parsed.state?.packets) ? parsed.state.packets : [],
			defaultEmail: parsed.state?.defaultEmail ?? ""
		};
	} catch {
		return null;
	}
}
async function pullDesk() {
	const remote = await listDesk();
	const local = readBrowserDrafts();
	const seen = new Set(remote.packets.map((packet) => packet.id));
	const extras = (local?.packets ?? []).filter((packet) => packet?.id && !seen.has(packet.id));
	useDesk.setState({
		packets: [...extras, ...remote.packets],
		defaultEmail: remote.defaultEmail || local?.defaultEmail || "",
		saveError: ""
	});
	if (local && typeof localStorage !== "undefined") localStorage.removeItem("lee-deal-desk");
	for (const packet of extras) {
		await saveDeskPacket({ data: packet });
		for (const file of packet.files ?? []) await uploadFile(packet.id, file);
	}
	if (local?.defaultEmail && !remote.defaultEmail) await saveDeskEmail({ data: local.defaultEmail });
	for (const packet of useDesk.getState().packets) for (const file of packet.files ?? []) {
		if (await getBlob(file.id)) continue;
		const downloaded = await fetchDeskFile({ data: file.id });
		if (!downloaded?.contentBase64) continue;
		const bytes = Uint8Array.from(atob(downloaded.contentBase64), (char) => char.charCodeAt(0));
		await putBlob(packet.id, file.id, new Blob([bytes], { type: downloaded.mime || file.type }));
	}
}
function ensureDesk(userId) {
	if (loadedFor === userId && loadPromise) return loadPromise;
	loadedFor = userId;
	loadPromise = pullDesk().catch((error) => {
		loadedFor = "";
		loadPromise = null;
		remember(error);
	});
	return loadPromise;
}
function useDeskHydrated() {
	const { user, isPending } = useCurrentUserState();
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (isPending) {
			setReady(false);
			return;
		}
		if (!user) {
			loadedFor = "";
			loadPromise = null;
			useDesk.setState({
				packets: [],
				defaultEmail: "",
				saveError: ""
			});
			setReady(true);
			return;
		}
		let stop = false;
		setReady(false);
		ensureDesk(user.id).then(() => {
			if (!stop) setReady(true);
		});
		return () => {
			stop = true;
		};
	}, [isPending, user?.id]);
	return ready && !isPending;
}
function useMember() {
	const { user, isPending } = useCurrentUserState();
	const [member, setMember] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (isPending) return;
		if (!user) {
			setMember(null);
			setPending(false);
			return;
		}
		let stop = false;
		setPending(true);
		whoAmI().then((me) => {
			if (!stop) setMember(me);
		}).catch(() => {
			if (!stop) setMember(null);
		}).finally(() => {
			if (!stop) setPending(false);
		});
		return () => {
			stop = true;
		};
	}, [isPending, user?.id]);
	return {
		member,
		role: member?.role ?? null,
		pending: isPending || pending
	};
}
async function hydrateSubmitted(id) {
	const row = await getSubmitted({ data: id });
	if (!row) return null;
	for (const file of row.files ?? []) {
		if (await getBlob(file.id)) continue;
		const downloaded = await fetchDeskFile({ data: file.id });
		if (!downloaded?.contentBase64) continue;
		const bytes = Uint8Array.from(atob(downloaded.contentBase64), (char) => char.charCodeAt(0));
		await putBlob(row.id, file.id, new Blob([bytes], { type: downloaded.mime || file.type }));
	}
	return row;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
//#endregion
export { splitNet as C, useDesk as D, useCurrentUserState as E, useDeskHydrated as O, saveBlob as S, storeIncoming as T, leaseMath as _, UserButton as a, saleCommission as b, deleteBlob as c, downloadPacket as d, downloadVoucher as f, hydrateSubmitted as g, getBlob as h, RedirectToSignIn as i, useMember as k, docGroups as l, formatBytes as m, KIND_META as n, blockers as o, emailPacket as p, KIND_ORDER as r, checkedWithoutFile as s, ACCEPT as t, dollars as u, packetFiles as v, splitPercentTotal as w, sampleAnswers as x, packetTitle as y };
