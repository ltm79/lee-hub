import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as getServerFnById, n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BVAF89CC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-mSmsEGFd.js
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var DOMAIN = "desk.local";
function loginEmail(username) {
	return `${username.trim().toLowerCase()}@${DOMAIN}`;
}
var prepareDesk = createServerFn({ method: "POST" }).handler(createSsrRpc("f326178d29573eda510c9509db2e373b48cf0ee36a73ecadc273d1a5b65b6720"));
var whoAmI = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7dc1e92a6fe7819fd44852847afc0fc314778b2bf4252d150cb462fd9274778f"));
var listPeople = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("526d307d0db9de9c235372db23d17712feb460b5e500b9d66c88a31c15e7fc5f"));
var createPerson = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("f703f679bec5ac4faba17db36563b1c3b6fc7c67c5949819623009b66a6c138d"));
var setPersonActive = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("bab8aa86194c12a1128daf6dc84c17d60e4fcfcb6b9b6180c2f453ec42976161"));
var resetPersonPassword = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("6ca3d1f5b858bdb233d8c7be21a83677c2088a28a33d9cee14d8bf751b916852"));
var listSubmitted = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("cde5b6e5a2de2132936dfe74fb962b48056884f7b57951b9e772bde836aa6262"));
var getSubmitted = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(createSsrRpc("457924139a1b2f1d2a36199a5baa7a21421058a0b58f16aa9f08a7741493e514"));
function Field({ name, label, value, onChange, placeholder, className = "", inputMode = "text", readOnly = false, multiline = false, hint }) {
	const id = `f-${name}`;
	const shared = "mt-1 w-full rounded-md border border-line bg-card px-3 text-sm text-ink placeholder:text-muted focus-visible:border-red focus-visible:outline-none";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		htmlFor: id,
		className: `block ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-ink-soft",
				children: label
			}),
			multiline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id,
				value,
				readOnly,
				rows: 4,
				placeholder,
				onChange: (event) => onChange?.(event.target.value),
				className: `${shared} py-2`
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				value,
				readOnly,
				inputMode,
				placeholder,
				autoComplete: name === "address" ? "street-address" : "off",
				onChange: (event) => onChange?.(event.target.value),
				className: `${shared} h-11 ${readOnly ? "bg-paper text-ink" : ""}`
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function Choice({ label, value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
		className: "text-sm text-ink-soft",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 flex flex-wrap gap-2",
		children: options.map((option) => {
			const selected = value === option.value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": selected,
				onClick: () => onChange(selected ? "" : option.value),
				className: `h-11 rounded-md border px-3 text-sm font-medium ${selected ? "border-red bg-red-soft text-red-deep" : "border-line bg-card text-ink hover:border-line-strong"}`,
				children: option.label
			}, option.value);
		})
	})] });
}
function Checks({ items, answers, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-2 sm:grid-cols-2",
		children: items.map((item) => {
			const on = answers[item.key] === "1";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: `flex min-h-11 items-start gap-3 rounded-md border px-3 py-2.5 text-sm ${on ? "border-red bg-red-soft" : "border-line bg-card"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: on,
					onChange: (event) => onChange(item.key, event.target.checked ? "1" : ""),
					className: "mt-0.5 size-4 accent-red"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
			}) }, item.key);
		})
	});
}
function Card({ title, eyebrow, children, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-lg border border-line bg-card p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-red",
				children: eyebrow
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl text-ink",
				children: title
			})] }), action]
		}), children]
	});
}
function PrimaryButton({ className = "", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: `inline-flex h-11 items-center justify-center gap-2 rounded-md bg-red px-4 text-sm font-semibold text-card hover:bg-red-deep disabled:opacity-50 ${className}`,
		...props
	});
}
function SecondaryButton({ className = "", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: `inline-flex h-11 items-center justify-center gap-2 rounded-md border border-line-strong bg-card px-4 text-sm font-semibold text-ink hover:border-ink disabled:opacity-50 ${className}`,
		...props
	});
}
function read(answers, key) {
	return answers[key] ?? "";
}
//#endregion
export { whoAmI as _, PrimaryButton as a, createSsrRpc as c, listSubmitted as d, loginEmail as f, setPersonActive as g, resetPersonPassword as h, Field as i, getSubmitted as l, read as m, Checks as n, SecondaryButton as o, prepareDesk as p, Choice as r, createPerson as s, Card as t, listPeople as u };
