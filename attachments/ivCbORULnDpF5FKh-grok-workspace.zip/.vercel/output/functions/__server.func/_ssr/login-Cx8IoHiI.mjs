import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as authClient } from "./client-CH2mWUg4.mjs";
import { _ as whoAmI, a as PrimaryButton, f as loginEmail, p as prepareDesk } from "./ui-mSmsEGFd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-Cx8IoHiI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BEARER_KEY = "grok-auth.bearer-token";
function keepToken(ctx) {
	const token = ctx.response.headers.get("set-auth-token");
	if (!token) return;
	try {
		sessionStorage.setItem(BEARER_KEY, token);
	} catch {}
}
function LoginPage() {
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		prepareDesk().catch(() => setError("The desk is not ready to sign in yet."));
	}, []);
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		const handle = username.trim().toLowerCase();
		if (!/^[a-z][a-z0-9._-]{1,31}$/.test(handle) || password.length < 8) {
			setError("Use the username and password an admin gave you.");
			return;
		}
		setPending(true);
		const result = await authClient.signIn.email({
			email: loginEmail(handle),
			password,
			callbackURL: "/"
		}, { onSuccess: keepToken });
		if (result.error) {
			setPending(false);
			setError(result.error.message || "That username or password is wrong.");
			return;
		}
		if (!await whoAmI().catch(() => null)) {
			try {
				sessionStorage.removeItem(BEARER_KEY);
			} catch {}
			await authClient.signOut();
			setPending(false);
			setError("This login is not on the desk.");
			return;
		}
		window.location.assign("/");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-red" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto grid min-h-[80vh] max-w-md place-items-center px-4 py-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-red",
						children: "Lee & Associates"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl",
						children: "Deal Desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-ink-soft",
						children: "Sign in with the username an admin assigned. Agents see their own drafts. Staff see submitted vouchers."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-6 grid gap-3",
						onSubmit: (event) => void onSubmit(event),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-ink-soft",
									children: "Username"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: username,
									autoCapitalize: "none",
									autoComplete: "username",
									onChange: (event) => setUsername(event.target.value),
									className: "mt-1 h-11 w-full rounded-md border border-line bg-card px-3 text-sm text-ink focus-visible:border-red focus-visible:outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-ink-soft",
									children: "Password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									value: password,
									autoComplete: "current-password",
									onChange: (event) => setPassword(event.target.value),
									className: "mt-1 h-11 w-full rounded-md border border-line bg-card px-3 text-sm text-ink focus-visible:border-red focus-visible:outline-none"
								})]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-red-deep",
								children: error
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								type: "submit",
								disabled: pending,
								children: pending ? "Signing in…" : "Sign in"
							})
						]
					})
				]
			})
		})]
	});
}
//#endregion
export { LoginPage as component };
