import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PrimaryButton, d as listSubmitted, g as setPersonActive, h as resetPersonPassword, o as SecondaryButton, s as createPerson, u as listPeople } from "./ui-mSmsEGFd.mjs";
import { D as useDesk, E as useCurrentUserState, O as useDeskHydrated, a as UserButton, d as downloadPacket, f as downloadVoucher, g as hydrateSubmitted, i as RedirectToSignIn, k as useMember, n as KIND_META, r as KIND_ORDER, v as packetFiles, x as sampleAnswers, y as packetTitle } from "./gates-DYOQ7Lhd.mjs";
import { c as FileText, d as Banknote, o as Handshake, r as Trash2, s as FolderArchive, u as Building2 } from "../_libs/lucide-react.mjs";
import { t as formatDistanceToNow } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DQl_PnLr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PeoplePanel() {
	const [people, setPeople] = (0, import_react.useState)([]);
	const [username, setUsername] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("agent");
	const [error, setError] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function refresh() {
		setPeople(await listPeople());
	}
	(0, import_react.useEffect)(() => {
		refresh().catch(() => setError("The user list could not be loaded."));
	}, []);
	async function onCreate(event) {
		event.preventDefault();
		setBusy(true);
		setError("");
		setNote("");
		try {
			await createPerson({ data: {
				username,
				name,
				password,
				role
			} });
			setUsername("");
			setName("");
			setPassword("");
			setNote(`${name.trim()} can sign in now.`);
			await refresh();
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "That person could not be added.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl",
			children: "People"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm text-muted",
			children: "Agents keep their own drafts. Staff can open every voucher an agent has submitted, including the backup files."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 grid gap-3 sm:grid-cols-2",
			onSubmit: (event) => void onCreate(event),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-ink-soft",
						children: "Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (event) => setName(event.target.value),
						className: "mt-1 h-11 w-full rounded-md border border-line bg-card px-3 text-sm"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-ink-soft",
						children: "Username"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: username,
						autoCapitalize: "none",
						onChange: (event) => setUsername(event.target.value),
						className: "mt-1 h-11 w-full rounded-md border border-line bg-card px-3 text-sm"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-ink-soft",
						children: "Password"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "password",
						value: password,
						onChange: (event) => setPassword(event.target.value),
						className: "mt-1 h-11 w-full rounded-md border border-line bg-card px-3 text-sm"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-ink-soft",
						children: "Role"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: role,
						onChange: (event) => setRole(event.target.value === "staff" ? "staff" : "agent"),
						className: "mt-1 h-11 w-full rounded-md border border-line bg-card px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "agent",
							children: "Agent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "staff",
							children: "Staff"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						type: "submit",
						disabled: busy,
						children: busy ? "Adding…" : "Add person"
					})
				})
			]
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-red-deep",
			children: error
		}) : null,
		note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-ink-soft",
			children: note
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-2",
			children: people.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonRow, {
				person,
				onChange: () => void refresh()
			}, person.userId))
		})
	] });
}
function PersonRow({ person, onChange }) {
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-lg border border-line bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-ink",
					children: person.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						person.username,
						" · ",
						person.role,
						person.active ? "" : " · off"
					]
				})] }), person.role === "admin" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
					onClick: () => {
						setPersonActive({ data: {
							userId: person.userId,
							active: !person.active
						} }).then(onChange).catch((caught) => setError(caught instanceof Error ? caught.message : "Could not update that login."));
					},
					children: person.active ? "Turn off" : "Turn on"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-3 flex flex-wrap gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					setError("");
					resetPersonPassword({ data: {
						userId: person.userId,
						password
					} }).then(() => {
						setPassword("");
					}).catch((caught) => setError(caught instanceof Error ? caught.message : "Could not reset the password."));
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					value: password,
					placeholder: "New password",
					"aria-label": `New password for ${person.username}`,
					onChange: (event) => setPassword(event.target.value),
					className: "h-11 min-w-0 flex-1 rounded-md border border-line bg-paper px-3 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
					type: "submit",
					children: "Reset password"
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-red-deep",
				children: error
			}) : null
		]
	});
}
var ICONS = {
	lease: Building2,
	sale: FileText,
	consult: Handshake,
	additional: Banknote
};
function HomePage() {
	const navigate = useNavigate();
	const ready = useDeskHydrated();
	const { user, isPending } = useCurrentUserState();
	const { member, role, pending: memberPending } = useMember();
	const [submitted, setSubmitted] = (0, import_react.useState)([]);
	const packets = useDesk((state) => state.packets);
	const saveError = useDesk((state) => state.saveError);
	const createPacket = useDesk((state) => state.createPacket);
	const removePacket = useDesk((state) => state.removePacket);
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (role !== "admin" && role !== "staff") return;
		listSubmitted().then(setSubmitted).catch(() => setError("Submitted vouchers could not be loaded."));
	}, [role]);
	const visible = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return [...packets].sort((a, b) => b.updatedAt - a.updatedAt).filter((packet) => filter === "all" ? true : packet.status === filter).filter((packet) => {
			if (!needle) return true;
			return `${packet.answers.address ?? ""} ${packet.answers.city ?? ""} ${KIND_META[packet.kind].title} ${packetFiles(packet).map((file) => file.name).join(" ")}`.toLowerCase().includes(needle);
		});
	}, [
		packets,
		query,
		filter
	]);
	function openNew(kind, answers) {
		const id = createPacket(kind, answers);
		navigate({
			to: "/vouchers/$id",
			params: { id }
		});
	}
	if (!ready || isPending || memberPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Opening your desk…"
		})
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!member) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "This login is not on the desk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-ink-soft",
				children: "Ask an admin for a username and password."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
			})
		]
	});
	const office = role === "admin" || role === "staff";
	const filing = role === "agent" || role === "admin";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-red" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-line bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-widest text-red",
								children: "Lee & Associates"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-serif text-4xl text-ink sm:text-5xl",
							children: "Deal Desk"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-2xl text-base text-ink-soft",
							children: role === "staff" ? "Submitted vouchers from every agent land here, with the backup files attached to them." : role === "admin" ? "Add agents and staff, then review what has been submitted." : "Your drafts stay on this username. Start a voucher here and it is waiting the next time you sign in."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid max-w-6xl gap-8 px-4 py-6 sm:px-6 sm:py-8",
				children: [
					saveError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-red-deep",
						children: saveError
					}) : null,
					role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PeoplePanel, {}) : null,
					office ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl",
							children: "Submitted"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-2xl text-sm text-muted",
							children: "Agents still finish their own drafts. This list is only what they have marked submitted."
						}),
						submitted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted",
							children: "Nothing has been submitted yet."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 grid gap-2",
							children: submitted.map((packet) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-lg border border-line bg-card p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold uppercase tracking-widest text-red",
										children: [
											KIND_META[packet.kind].short,
											" · ",
											packet.agentName
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-serif text-2xl",
										children: packetTitle(packet)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											packet.username,
											packet.answers.city ? ` · ${packet.answers.city}` : "",
											packetFiles(packet).length ? ` · ${packetFiles(packet).length} file${packetFiles(packet).length === 1 ? "" : "s"}` : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
										className: "mt-3",
										onClick: () => {
											hydrateSubmitted(packet.id).then(() => navigate({
												to: "/vouchers/$id",
												params: { id: packet.id }
											}));
										},
										children: "Open"
									})
								]
							}, packet.id))
						})
					] }) : null,
					filing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "New voucher"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
						children: KIND_ORDER.map((kind) => {
							const meta = KIND_META[kind];
							const Icon = ICONS[kind];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "flex flex-col rounded-lg border border-line bg-card p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5 text-red",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-3 font-serif text-2xl",
										children: meta.short
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs font-medium uppercase tracking-widest text-muted",
										children: meta.pages
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 flex-1 text-sm text-ink-soft",
										children: meta.blurb
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
										className: "mt-4 w-full",
										onClick: () => openNew(kind),
										children: "Start"
									})
								]
							}, kind);
						})
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: "Packets"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
								onClick: () => openNew("lease", sampleAnswers()),
								children: "Open a sample lease"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-2xl text-sm text-muted",
							children: "Drafts stay on your username. Marking a packet submitted is what staff can open."
						}),
						!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-muted",
							children: "Loading saved packets…"
						}) : packets.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-lg border border-dashed border-line-strong bg-card px-4 py-8 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-2xl",
								children: "No packets yet"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-2 max-w-md text-sm text-ink-soft",
								children: "Start a blank voucher, or open the sample lease to see the rent schedule and commission math already filled in."
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-3 sm:flex-row sm:items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: query,
										onChange: (event) => setQuery(event.target.value),
										placeholder: "Search address or city",
										className: "h-11 w-full rounded-md border border-line bg-card px-3 text-sm sm:max-w-xs",
										"aria-label": "Search packets"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex gap-2",
										children: [
											["all", "All"],
											["draft", "Drafts"],
											["submitted", "Submitted"]
										].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": filter === id,
											onClick: () => setFilter(id),
											className: `h-11 rounded-md border px-3 text-sm font-medium ${filter === id ? "border-ink bg-ink text-card" : "border-line bg-card text-ink"}`,
											children: label
										}, id))
									})]
								}),
								visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Nothing matches that filter."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "grid gap-2",
									children: visible.map((packet) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "rounded-lg border border-line bg-card p-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-start justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-xs font-semibold uppercase tracking-widest text-red",
														children: [KIND_META[packet.kind].short, packet.answers.sample === "1" ? " · Sample" : ""]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
														className: "truncate font-serif text-2xl",
														children: packetTitle(packet)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-sm text-muted",
														children: [
															packet.answers.city ? `${packet.answers.city} · ` : "",
															packet.status === "submitted" ? "Submitted" : "Draft",
															packetFiles(packet).length ? ` · ${packetFiles(packet).length} file${packetFiles(packet).length === 1 ? "" : "s"}` : "",
															" · ",
															"updated ",
															formatDistanceToNow(packet.updatedAt, { addSuffix: true })
														]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
														onClick: () => void navigate({
															to: "/vouchers/$id",
															params: { id: packet.id }
														}),
														children: "Open"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
														onClick: () => {
															setError("");
															downloadPacket(packet).then((leftOut) => {
																if (leftOut > 0) setError("A file from this packet is no longer in this browser and was left out.");
															}).catch(() => setError("The packet could not be built."));
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderArchive, {
															className: "size-4",
															"aria-hidden": "true"
														}), "Packet"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
														onClick: () => {
															setError("");
															downloadVoucher(packet).catch(() => setError("The PDF could not be built."));
														},
														children: "PDF"
													}),
													pendingDelete === packet.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
														onClick: () => {
															removePacket(packet.id);
															setPendingDelete(null);
														},
														children: "Confirm delete"
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														"aria-label": `Delete ${packetTitle(packet)}`,
														onClick: () => setPendingDelete(packet.id),
														className: "inline-flex size-11 items-center justify-center rounded-md border border-line text-ink-soft",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
															className: "size-4",
															"aria-hidden": "true"
														})
													})
												]
											})]
										})
									}, packet.id))
								}),
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-red-deep",
									children: error
								}) : null
							]
						})
					] })] }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mx-auto max-w-6xl px-4 pb-10 text-xs text-muted sm:px-6",
				children: "500 Citadel Dr. #140, Commerce · 13181 Crossroads Pkwy N #300, City of Industry"
			})
		]
	});
}
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
