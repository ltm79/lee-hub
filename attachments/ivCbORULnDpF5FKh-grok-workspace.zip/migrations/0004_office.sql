alter table desk_members add column if not exists office text not null default '';
