create table if not exists desk_members (
  user_id text primary key,
  username text not null unique,
  name text not null,
  role text not null,
  active boolean not null default true
);

create index if not exists desk_members_role_idx on desk_members (role);
